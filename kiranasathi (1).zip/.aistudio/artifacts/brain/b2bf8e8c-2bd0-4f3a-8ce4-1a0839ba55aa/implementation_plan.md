# KiranaSathi — Offline-First Kirana Shop Manager (Android)

KiranaSathi is an ultra-simple, offline-first Android point-of-sale, inventory, and Udhar (credit) ledger application tailored for Nepali Kirana stores. It pairs a high-contrast Crisp Teal & White counter interface with one-tap visual billing, instant English/Nepali (`नेपाली`) switching, WhatsApp Udhar reminders, QR display, and portable JSON/CSV backups.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> All four architectural and product choices from our clarification round are locked into this plan. Review the summary and recommended defaults below before approving the build.

- **Confirmed — Storage & Backup**: 100% offline **Room** SQLite database paired with **DataStore** preferences, plus local **JSON and CSV Export/Import** via Android's Storage Access Framework (no internet or login required).
- **Confirmed — Starter Catalog**: Pre-loaded with common Nepali Kirana items (Rice, Cooking Oil, Dal, Wai Wai Noodles, Biscuits, Dairy, Tea, Spices, Soap) on first launch so the counter can be tested and used immediately.
- **Confirmed — Visual Theme**: **Clean Modern Retail** — Crisp Teal (`#0D7377`) and Pure White (`#FFFFFF` / `#F6FAFA`) surfaces with bold tabular numerals and color-coded category iconography.
- **Confirmed — Default Language**: Launches in **English** with a persistent one-tap **`EN / ने`** toggle pill in the top bar that switches the entire app between English and Nepali (`नेपाली`) instantaneously.
- **Recommended Default — Security & Shop Profile**: A 4-digit numeric Master PIN set once on first launch (with optional Shop Name, defaulting to *"Mero Kirana Pasal"*), auto-login on subsequent launches, and an instant **Lock App** button in Settings.
- **Recommended Default — QR & WhatsApp Integration**: Payment QR codes (eSewa, Khalti, Fonepay, Bank QR) are picked via the zero-permission **Android Photo Picker** and copied into private app storage; Udhar reminders launch WhatsApp via standard deep links with a share-sheet fallback if WhatsApp is not installed.

---

## 1. Overview & Core Concept

- **What It Does**: Replaces paper *hisab* notebooks and manual calculators with a five-pillar counter toolkit:
  1. **Instant POS Counter**: Tap large visual product tiles to build a bill, compute change instantly, display the shop's payment QR code, and finalize Cash, QR, or Udhar sales in one tap.
  2. **Master Inventory & Smart Refill**: Add items with visual category icons, NPR rates (`रु.`), cost prices, and stock counts; restock rapidly using `+1`, `+5`, `+10` quick-tap pills or direct numeric entry.
  3. **Udhar Khata & Reminder Queue**: Track customer credit balances, record partial/full payments, fire pre-formatted Nepali WhatsApp reminders, and step through an overdue **Reminder Queue**.
  4. **Cash Wallet & Daily Summary**: View live drawer cash, daily Cash/QR/Udhar revenue splits, total pending Udhar, and estimated net profit.
  5. **More, QR & Backup**: Display/update the shop's payment QR code, export/import `.json` or `.csv` backups, customize Shop Name, change language, or lock the app.
- **Target Audience / Persona**: Nepali Kirana store owners, spouses, elders, and young family helpers operating a busy shop counter on an Android phone or tablet—often one-handed, offline, and under time pressure.
- **Key Value**: Zero learning curve, 100% offline reliability, instant bilingual clarity (`Rate / रेट`, `Udhar / उधार`, `Hisab / हिसाब`), and faster Udhar recovery via one-tap Nepali WhatsApp messages.

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌─────────────────────────────────────────────────────────────────────────┐
│ FIRST LAUNCH                                                            │
│  Shop Name + Set 4-Digit Master PIN  ──►  Pre-seed Kirana Catalog       │
│  (Saved locally; auto-login enabled on all future app launches)         │
└────────────────────────────────────┬────────────────────────────────────┘
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ MAIN WORKSPACE (Persistent Top Bar: Shop Title + [EN | ने] Toggle)      │
│                                                                         │
│  [1. Counter POS]   [2. Inventory]   [3. Udhar]   [4. Wallet]  [5. More]│
│   • Category chips   • Stock badges   • Customer   • Drawer     • QR    │
│   • Visual item grid • +1/+5/+10      • Balance      Cash       • JSON/ │
│   • Sticky cart bar    refill modal   • WhatsApp   • Sales        CSV   │
│   • Cash/QR/Udhar    • Add/Edit item    Reminder   • Profit     • Lock  │
│     1-tap checkout                      Queue      • Udhar Tot    App   │
└─────────────────────────────────────────────────────────────────────────┘
```

1. **Onboarding & Lock Gate**: First-time launch presents a clean keypad to set a 4-digit Master PIN and optional Shop Name. Future opens skip straight to the **Counter POS**. Tapping **Lock App** in *More* resets the active session state and displays the PIN Unlock keypad.
2. **Instant Counter Billing**: Shopkeeper filters by visual category chips (*All, Grains, Oil, Noodles, Biscuits, Dairy, Spices, Drinks, Home*) or searches, taps big product cards (each showing icon, Nepali/English name, `रु.` rate, and stock pill), and sees a sticky bottom Cart Dock (`Items • Total रु.`). Tapping **Checkout** opens a streamlined Payment Sheet with:
   - Payment mode pills: **Cash (नगद)**, **QR Pay (QR भुक्तानी)**, **Udhar (उधार)**.
   - For **Cash**: Quick NPR denomination chips (`+100`, `+500`, `+1000`, `Exact`) + numeric input showing live **Change / फिर्ता**.
   - For **QR Pay**: Displays the shopkeeper's uploaded eSewa/Khalti/Fonepay QR code directly on screen for the customer to scan.
   - For **Udhar**: Pick an existing customer or quick-create one right inside the sheet.
   - One tap on **Complete Sale** atomically deducts stock, logs the sale, updates the cash drawer / customer Udhar balance, and shows a brief confirmation banner.
3. **Inventory & Smart Refill**: List/grid of items with low-stock warning badges (`≤ 5`). Tapping **Refill** opens a focused bottom sheet with large `+1`, `+5`, `+10` stepper buttons plus a direct numeric field for bulk sacks/cartons, alongside an **Add / Edit Item** sheet with visual icon picker.
4. **Udhar Khata & Reminder Queue**: Top summary card shows Total Pending Udhar (`जम्मा बाँकी उधार`) and **Open Reminder Queue** button. Each customer row displays Name, Phone, Pending `रु.` balance, and two big actions: **Receive Payment (रकम बुझियो)** and **WhatsApp**. Inside the **Reminder Queue**, overdue/unpaid customers are queued for sequential 1-tap WhatsApp sending or daily/weekly summary copying.
5. **Wallet & Cashflow**: High-contrast metric grid showing Cash in Drawer (with quick **Cash In / Cash Out** drawer adjustment), Today's Sales Revenue (split by Cash, QR, Udhar), Total Pending Udhar, and Estimated Net Profit, plus recent transaction history.
6. **More & Settings**: Payment QR viewer & uploader, JSON/CSV Backup Export & Import Restore cards, Shop Name & PIN settings, and **Lock App**.

### Visual Identity & Theme

- **Aesthetic Direction**: **Clean Modern Retail** — crisp, sunlit counter clarity engineered for legibility in bright shop lighting, using generous touch targets (`≥ 48dp`, primary POS tiles `≥ 110dp`), zero clutter, and unmistakable color semantics.
- **Color Palette & Mood (Material 3 Tokens)**:
  - `primary`: Crisp Deep Teal (`#0D7377`) — primary CTAs, active navigation pill, checkout bar
  - `onPrimary`: Pure White (`#FFFFFF`)
  - `primaryContainer`: Soft Mint-Teal (`#D6F2F0`) — selected category chips & subtle active badges
  - `secondary`: Emerald Green (`#15803D`) — Cash payment, positive stock, profit indicators
  - `tertiary`: Warm Amber (`#D97706`) — Udhar pending badges, low-stock alerts, QR accent
  - `error`: Crisp Coral Red (`#DC2626`) — Out-of-stock, overdue debt, lock/reset actions
  - `background` / `surface`: Cool Alabaster (`#F5F9F9`) & Pure White (`#FFFFFF`) cards with crisp `1dp` hairline borders (`#DCE8E8`) for clean visual separation without heavy drop shadows.
- **Typography & Hierarchy**:
  - Bundled locally via `font-util` (zero runtime font download failures): **Plus Jakarta Sans** for bold UI headings/labels, **Noto Sans Devanagari** fallback/pairing for crisp Nepali script rendering, and **JetBrains Mono** (or `tnum` font feature settings) for aligned NPR currency figures (`रु. 1,250`).
  - Oversized numeric display (`24sp–32sp` bold) for totals, change due, and pending balances so numbers can be read at arm's length behind the counter.
- **Component Styling & Adaptive Layout**:
  - Edge-to-edge layout respecting `WindowInsets.safeDrawing` and `WindowInsets.navigationBars`.
  - **Compact screens (Phones)**: Top App Bar with Shop Name + `[EN | ने]` segmented toggle pill, main scrollable content, and 5-item Material 3 `NavigationBar` with crisp active indicators.
  - **Expanded screens (Counter Tablets / Foldables)**: Switches to a left `NavigationRail` and side-by-side POS grid + live Cart Receipt pane so tablet counters act like a full retail terminal.
- **Interactive Feedback & Motion**:
  - Material ripple feedback on every product tile, quantity pill, and action button.
  - Snappy spring animations (`< 250ms`) for cart count badge bumps, bottom sheet transitions, and instant bilingual label switching.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: 100% Offline Room + DataStore Instead of Cloud Sync**
  - *Chosen Approach*: All structured records live in local Room SQLite tables; PIN, lock state, language, shop name, and QR image URI live in Jetpack DataStore Preferences.
  - *Why*: Eliminates internet dependency, Google Sign-In friction, and latency at busy Kirana counters while honoring the user's offline-first requirement.
  - *Trade-Off & Mitigation*: Device loss would risk local data, so we provide prominent one-tap **Export JSON / CSV** and **Import Restore** workflows in *More*.

- **Decision 2: Native Compose Vector/Canvas Category Artwork Over Stock Photos**
  - *Chosen Approach*: Provide a curated set of 10+ vibrant, color-coded vector/custom-drawn product & category badges (Rice Bag, Oil Bottle, Noodle Pack, Biscuit, Milk Carton, Spice Jar, Tea/Drink, Soap/Home, Pulse/Dal, Scales).
  - *Why*: Keeps APK size compact, guarantees instant rendering with zero loading lag, and stays sharp at any scale for non-readers or young helpers.

- **Decision 3: Single-Activity Bilingual String Registry**
  - *Chosen Approach*: Maintain a reactive `AppLanguage` (`EN` / `NE`) state in DataStore observed via `CompositionLocal` across every screen, dialog, and currency formatter.
  - *Why*: Toggling `EN / ने` updates every label, button, category name, and Nepali commerce term (*Udhar/उधार*, *Hisab/हिसाब*, *Rate/रेट*) instantaneously with zero Activity recreation or lost cart state.

- **Decision 4: Zero-Permission Photo Picker & SAF File Backup**
  - *Chosen Approach*: Use `ActivityResultContracts.PickVisualMedia` to load the shopkeeper's payment QR code (copying the bitmap into private internal app storage) and `CreateDocument` / `OpenDocument` for `.json` / `.csv` backups.
  - *Why*: Complies strictly with Google Play storage privacy policies—zero broad storage permissions (`READ_EXTERNAL_STORAGE` / `READ_MEDIA_IMAGES`) needed on any Android version.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│ UI LAYER (Jetpack Compose + Material 3 + Adaptive Phone/Tablet Layout)  │
│  • PinGateScreen (Setup / Unlock)                                       │
│  • MainShell (TopBar + [EN|ने] Toggle + NavBar/NavRail)                 │
│     ├── CounterPosScreen  ──► Cart & Checkout Sheet (Cash/QR/Udhar)     │
│     ├── InventoryScreen   ──► Refill (+1/+5/+10) & Item Editor Sheets   │
│     ├── UdharKhataScreen  ──► Customer Ledger & Reminder Queue Sheet    │
│     ├── WalletScreen      ──► Daily Cashflow, Profit & Drawer Adjust    │
│     └── MoreScreen        ──► QR Display/Upload, Backup JSON/CSV, Lock  │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ StateFlow / Events
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ VIEWMODEL & DOMAIN LAYER                                                │
│  • KiranaViewModel (Unifies POS cart, bilingual state, PIN gate,        │
│    atomic checkouts, Udhar reminders, cashflow metrics, backup I/O)     │
│  • BackupSerializer (JSON full-store snapshot & CSV tabular exporter)   │
│  • WhatsAppReminderHelper (Nepali template builder + Intent launcher)   │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ Suspend & Flow<T>
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ DATA LAYER (Offline-First Persistence)                                  │
│  • KiranaRepository ──► Room Database (KSP)                             │
│     ├── ProductEntity (id, nameEn, nameNe, price, costPrice, stock,     │
│     │                  category, iconKey, updatedAt)                    │
│     ├── CustomerEntity (id, name, phone, balance, lastRemindedAt)       │
│     ├── SaleEntity & SaleItemEntity (items, total, profit, mode, time)  │
│     ├── UdharTransactionEntity (customerId, type, amount, note, time)   │
│     └── CashAdjustmentEntity (type IN/OUT, amount, note, timestamp)     │
│  • PreferencesStore ──► Jetpack DataStore (PIN hash, isUnlocked,        │
│                         language, shopName, qrImagePath, reminderFreq)  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **ProductEntity**: `id`, `nameEn`, `nameNe`, `category` (enum: Grains, Oil, Noodles, Biscuits, Dairy, Spices, Drinks, Household, Other), `iconKey`, `sellingPrice` (Double NPR), `costPrice` (Double NPR, defaults reasonably for starter items & profit math), `stockCount` (Int), `unitLabel` (e.g., *pkt, kg, ltr, pcs*), `updatedAt`.
- **CustomerEntity**: `id`, `name`, `phone`, `pendingBalance` (Double NPR), `lastRemindedAt` (Long?), `createdAt`.
- **SaleEntity + SaleItemEntity**: Captures every finalized transaction with `paymentMode` (`CASH`, `QR`, `UDHAR`), `customerId` (nullable), `totalAmount`, `estimatedProfit`, `cashReceived`, `changeGiven`, and `timestamp`, plus itemized line records for receipts and CSV export.
- **UdharTransactionEntity**: Immutable ledger entries per customer (`CREDIT_ADDED` from POS or manual entry, `PAYMENT_RECEIVED` cash/QR settlement) so full customer *hisab* history is always auditable.
- **CashAdjustmentEntity**: Manual drawer deposits (opening float) or cash-out expenses so **Cash in Drawer** accurately reflects Cash Sales + Cash Udhar Collections + Cash In − Cash Out.
- **PreferencesStore (DataStore)**: `pinHash` (SHA-256 salted locally), `isSessionLocked` (false after initial PIN creation so subsequent launches auto-login until user taps **Lock App**), `language` (`EN` default / `NE`), `shopName`, `qrFilePath`, and `reminderCadence` (`DAILY` / `WEEKLY`).

### Interactive Component & State Mapping

- **PIN Gate Flow**: On cold start, `KiranaViewModel` reads DataStore. If `pinHash` is blank -> show **One-Time Master PIN Setup**; saving hashes PIN, sets `isSessionLocked = false`, seeds Room starter items (if DB empty), and enters POS. If `pinHash` exists and `isSessionLocked == false` -> auto-login straight to POS. Tapping **Lock App** sets `isSessionLocked = true` -> immediately returns to PIN Unlock keypad.
- **POS Cart & Atomic Checkout**: Tapping a product tile increments its cart quantity (bounded cleanly with low/zero-stock visual warning). Confirming checkout executes a single Room `@Transaction`: inserts `SaleEntity` + `SaleItemEntity` rows, decrements `ProductEntity.stockCount`, and—if `paymentMode == UDHAR`—increments `CustomerEntity.pendingBalance` and appends a `UdharTransactionEntity`.
- **Smart Refill**: Refill sheet holds temporary `deltaQuantity` state updated by `+1`, `+5`, `+10` taps or direct keyboard input; confirming updates `stockCount` reactively in Room and refreshes both Inventory and POS grids immediately.
- **WhatsApp Udhar Reminder & Queue**: Formats the exact Nepali message:
  `"नमस्ते [Customer Name] ज्यू, [Shop Name] मा तपाईँको रु. [Amount] बाँकी हिसाब रहेको छ। कृपया यथाशीघ्र भुक्तानी गरिदिनुहोला। धन्यवाद!"`
  Launches WhatsApp (`https://wa.me/<sanitizedPhone>?text=<encodedMessage>`) with a fallback share intent, and updates `lastRemindedAt`. The **Reminder Queue** filters unpaid customers (`pendingBalance > 0`), ranks oldest-reminded/highest-balance first, allows stepping through one by one, and generates a copyable daily/weekly debt summary log.
- **Backup & Restore**:
  - *Export JSON*: Serializes all tables + shop settings into a structured JSON document written via SAF `CreateDocument`.
  - *Export CSV*: Generates a clean multi-section or tabular CSV report of Inventory, Udhar Customers, and Sales History written via SAF `CreateDocument`.
  - *Import / Restore*: Reads a `.json` (or compatible `.csv`) backup via SAF `OpenDocument`, validates structure, and atomically replaces/restores Room entities + preferences with clear success/error feedback.

### APK Delivery Note

- In this Android build environment, the full Kotlin + Jetpack Compose project builds cleanly into an installable APK, and you can preview the running app in the Streaming Emulator or export/generate the APK directly from the project build output / AI Studio export menu.
