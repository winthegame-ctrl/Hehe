package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PeopleOutline
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.CustomerEntity
import com.example.data.UdharEntryType
import com.example.data.UdharTransactionEntity
import com.example.i18n.LocalStrings
import com.example.i18n.formatNpr
import com.example.ui.KiranaUiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.KiranaPillChip
import com.example.ui.components.KiranaSearchField
import com.example.ui.components.RetailCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.KiranaTokens
import com.example.ui.theme.NumericDisplayStyle
import com.example.util.DateTimeHelper
import com.example.util.WhatsAppHelper

private enum class UdharAmountMode {
    ADD_CREDIT,
    RECEIVE_PAYMENT
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UdharKhataScreen(
    uiState: KiranaUiState,
    onAddCustomer: (String, String, Double, String) -> Unit,
    onAddManualUdhar: (Long, Double, String) -> Unit,
    onReceivePayment: (Long, Double, String) -> Unit,
    onSendWhatsApp: (CustomerEntity) -> Unit,
    onMarkReminderSent: (CustomerEntity) -> Unit,
    onSetReminderCadence: (String) -> Unit,
    onBuildSummaryLog: () -> String,
    onNotify: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    val clipboard = LocalClipboardManager.current
    var searchQuery by remember { mutableStateOf("") }
    var unpaidOnly by remember { mutableStateOf(false) }
    var showAddCustomerSheet by remember { mutableStateOf(false) }
    var showReminderQueueSheet by remember { mutableStateOf(false) }
    var historyCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var amountTarget by remember { mutableStateOf<Pair<CustomerEntity, UdharAmountMode>?>(null) }

    val unpaidList = uiState.unpaidCustomers
    val filteredCustomers = remember(uiState.customers, searchQuery, unpaidOnly) {
        uiState.customers.filter { c ->
            val matchFilter = !unpaidOnly || c.pendingBalance > 0.0
            val q = searchQuery.trim()
            val matchText = q.isEmpty() ||
                c.name.contains(q, ignoreCase = true) ||
                c.phone.contains(q, ignoreCase = true)
            matchFilter && matchText
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Pending Udhar Banner (Pale Amber #FEF6DC with hairline border)
        RetailCard(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
            borderColor = MaterialTheme.colorScheme.outline,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = KiranaTokens.ScreenGutter, vertical = 12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = strings.totalPendingUdhar,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        Text(
                            text = formatNpr(uiState.walletSummary.totalPendingUdhar),
                            style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.headlineMedium.fontSize),
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${unpaidList.size}",
                                style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            Text(
                                text = strings.unpaidCustomersCount,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showAddCustomerSheet = true },
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("add_customer_button")
                    ) {
                        Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.addCustomerBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    OutlinedButton(
                        onClick = { showReminderQueueSheet = true },
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("open_reminder_queue_button")
                    ) {
                        Icon(
                            Icons.Rounded.NotificationsActive,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${strings.reminderQueueBtn} (${unpaidList.size})",
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Search & Filter Pill
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = KiranaTokens.ScreenGutter),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            KiranaSearchField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = strings.searchCustomerHint,
                modifier = Modifier.weight(1f)
            )
            KiranaPillChip(
                label = if (unpaidOnly) strings.filterUnpaid else strings.filterAll,
                selected = unpaidOnly,
                selectedContainerColor = MaterialTheme.colorScheme.tertiary,
                onClick = { unpaidOnly = !unpaidOnly },
                modifier = Modifier.testTag("udhar_filter_unpaid")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (filteredCustomers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = KiranaTokens.ScreenGutter, vertical = 12.dp)
            ) {
                EmptyStateCard(
                    icon = Icons.Rounded.PeopleOutline,
                    message = strings.noUdharCustomersEmpty,
                    actionLabel = strings.addCustomerBtn,
                    onAction = { showAddCustomerSheet = true }
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = KiranaTokens.ScreenGutter, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(KiranaTokens.CardSpacing),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredCustomers, key = { it.id }) { customer ->
                    CustomerUdharCard(
                        customer = customer,
                        onOpenHistory = { historyCustomer = customer },
                        onAddUdhar = { amountTarget = customer to UdharAmountMode.ADD_CREDIT },
                        onReceivePayment = { amountTarget = customer to UdharAmountMode.RECEIVE_PAYMENT },
                        onSendWhatsApp = { onSendWhatsApp(customer) }
                    )
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }

    if (showAddCustomerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddCustomerSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            AddCustomerSheetContent(
                onSave = { name, phone, initialAmount, note ->
                    onAddCustomer(name, phone, initialAmount, note)
                    showAddCustomerSheet = false
                },
                onCancel = { showAddCustomerSheet = false }
            )
        }
    }

    amountTarget?.let { (customer, mode) ->
        ModalBottomSheet(
            onDismissRequest = { amountTarget = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            UdharAmountSheetContent(
                customer = customer,
                mode = mode,
                onConfirm = { amount, note ->
                    when (mode) {
                        UdharAmountMode.ADD_CREDIT -> onAddManualUdhar(customer.id, amount, note)
                        UdharAmountMode.RECEIVE_PAYMENT -> onReceivePayment(customer.id, amount, note)
                    }
                    amountTarget = null
                },
                onCancel = { amountTarget = null }
            )
        }
    }

    historyCustomer?.let { target ->
        val freshCustomer = uiState.customers.firstOrNull { it.id == target.id } ?: target
        val customerTx = uiState.udharTransactions.filter { it.customerId == target.id }
        ModalBottomSheet(
            onDismissRequest = { historyCustomer = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            CustomerHistorySheetContent(
                customer = freshCustomer,
                shopName = uiState.preferences.shopName,
                transactions = customerTx,
                onSendWhatsApp = { onSendWhatsApp(freshCustomer) },
                onClose = { historyCustomer = null }
            )
        }
    }

    if (showReminderQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showReminderQueueSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            ReminderQueueSheetContent(
                unpaidCustomers = unpaidList,
                shopName = uiState.preferences.shopName,
                cadence = uiState.preferences.reminderCadence,
                onSelectCadence = onSetReminderCadence,
                onSendWhatsApp = onSendWhatsApp,
                onMarkSent = onMarkReminderSent,
                onCopySummary = {
                    clipboard.setText(AnnotatedString(onBuildSummaryLog()))
                    onNotify(strings.summaryCopiedMsg)
                },
                onClose = { showReminderQueueSheet = false }
            )
        }
    }
}

@Composable
private fun CustomerUdharCard(
    customer: CustomerEntity,
    onOpenHistory: () -> Unit,
    onAddUdhar: () -> Unit,
    onReceivePayment: () -> Unit,
    onSendWhatsApp: () -> Unit
) {
    val strings = LocalStrings.current
    val hasDebt = customer.pendingBalance > 0.0

    RetailCard(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(KiranaTokens.CardRadius))
            .clickable(onClick = onOpenHistory)
            .testTag("customer_card_${customer.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                InitialsAvatar(
                    name = customer.name,
                    containerColor = if (hasDebt) MaterialTheme.colorScheme.tertiaryContainer
                    else MaterialTheme.colorScheme.primaryContainer,
                    contentColor = if (hasDebt) MaterialTheme.colorScheme.tertiary
                    else MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = customer.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = customer.phone.ifBlank { "—" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val lastReminded = customer.lastRemindedAt?.let {
                        "${strings.lastRemindedLabel}: ${DateTimeHelper.formatTimeOrDate(it)}"
                    } ?: strings.neverReminded
                    if (hasDebt) {
                        Text(
                            text = lastReminded,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (hasDebt) formatNpr(customer.pendingBalance) else strings.settledLabel,
                        style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                        color = if (hasDebt) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.History,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = strings.customerHistoryTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onAddUdhar,
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    shape = RoundedCornerShape(KiranaTokens.PillRadius),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("add_udhar_${customer.id}")
                ) {
                    Text(strings.addUdharBtn, maxLines = 1)
                }

                Button(
                    onClick = onReceivePayment,
                    enabled = hasDebt,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    shape = RoundedCornerShape(KiranaTokens.PillRadius),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("receive_udhar_${customer.id}")
                ) {
                    Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.receivePayBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }

                if (hasDebt) {
                    Button(
                        onClick = onSendWhatsApp,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("whatsapp_remind_${customer.id}")
                    ) {
                        Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.whatsappBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddCustomerSheetContent(
    onSave: (String, String, Double, String) -> Unit,
    onCancel: () -> Unit
) {
    val strings = LocalStrings.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var initialAmount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(strings.addCustomerBtn, style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(strings.customerNameLabel) },
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("new_customer_name_input")
        )
        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text(strings.phoneNumberLabel) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("new_customer_phone_input")
        )
        OutlinedTextField(
            value = initialAmount,
            onValueChange = { initialAmount = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("${strings.amountNprLabel} (${strings.noteOptionalLabel})") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text(strings.noteOptionalLabel) },
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) { Text(strings.cancelBtn) }
            Button(
                onClick = {
                    onSave(name, phone, initialAmount.toDoubleOrNull() ?: 0.0, note)
                },
                enabled = name.isNotBlank(),
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(2f)
                    .height(50.dp)
                    .testTag("save_new_customer_button")
            ) { Text(strings.saveCustomerBtn) }
        }
    }
}

@Composable
private fun UdharAmountSheetContent(
    customer: CustomerEntity,
    mode: UdharAmountMode,
    onConfirm: (Double, String) -> Unit,
    onCancel: () -> Unit
) {
    val strings = LocalStrings.current
    var amountText by remember {
        mutableStateOf(
            if (mode == UdharAmountMode.RECEIVE_PAYMENT && customer.pendingBalance > 0.0) {
                customer.pendingBalance.toLong().toString()
            } else ""
        )
    }
    var note by remember { mutableStateOf("") }
    val amount = amountText.toDoubleOrNull() ?: 0.0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = if (mode == UdharAmountMode.ADD_CREDIT) strings.recordUdharTitle
            else strings.receivePaymentTitle,
            style = MaterialTheme.typography.headlineSmall
        )
        Text(
            text = "${customer.name} • ${strings.pendingBalanceLabel}: ${formatNpr(customer.pendingBalance)}",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text(strings.amountNprLabel) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("udhar_amount_input")
        )
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text(strings.noteOptionalLabel) },
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) { Text(strings.cancelBtn) }
            Button(
                onClick = { onConfirm(amount, note) },
                enabled = amount > 0.0,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (mode == UdharAmountMode.RECEIVE_PAYMENT) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.tertiary
                    }
                ),
                modifier = Modifier
                    .weight(2f)
                    .height(50.dp)
                    .testTag("confirm_udhar_entry_button")
            ) { Text(strings.confirmEntryBtn) }
        }
    }
}

@Composable
private fun CustomerHistorySheetContent(
    customer: CustomerEntity,
    shopName: String,
    transactions: List<UdharTransactionEntity>,
    onSendWhatsApp: () -> Unit,
    onClose: () -> Unit
) {
    val strings = LocalStrings.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(customer.name, style = MaterialTheme.typography.headlineSmall)
                Text(
                    text = "${strings.pendingBalanceLabel}: ${formatNpr(customer.pendingBalance)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (customer.pendingBalance > 0) MaterialTheme.colorScheme.tertiary
                    else MaterialTheme.colorScheme.primary
                )
            }
            if (customer.pendingBalance > 0) {
                Button(
                    onClick = onSendWhatsApp,
                    shape = RoundedCornerShape(KiranaTokens.PillRadius),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E))
                ) {
                    Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.whatsappBtn)
                }
            }
        }

        if (customer.pendingBalance > 0) {
            Spacer(modifier = Modifier.height(10.dp))
            RetailCard(
                containerColor = MaterialTheme.colorScheme.background,
                borderColor = BorderSubtle,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = WhatsAppHelper.buildUdharReminderMessage(
                        customer.name,
                        shopName,
                        customer.pendingBalance
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = BorderSubtle)
        Spacer(modifier = Modifier.height(10.dp))

        if (transactions.isEmpty()) {
            Text(
                text = strings.noHistoryEmpty,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 20.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(transactions, key = { it.id }) { tx ->
                    val isCredit = tx.entryType == UdharEntryType.CREDIT_ADDED.name
                    RetailCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isCredit) strings.creditGivenTag else strings.paymentReceivedTag,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isCredit) MaterialTheme.colorScheme.tertiary
                                    else MaterialTheme.colorScheme.primary
                                )
                                if (tx.note.isNotBlank()) {
                                    Text(
                                        text = tx.note,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = DateTimeHelper.formatTimeOrDate(tx.timestamp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = (if (isCredit) "+" else "-") + formatNpr(tx.amount),
                                style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleMedium.fontSize),
                                color = if (isCredit) MaterialTheme.colorScheme.tertiary
                                else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
            onClick = onClose,
            shape = RoundedCornerShape(KiranaTokens.PillRadius),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(strings.closeBtn)
        }
    }
}

@Composable
private fun ReminderQueueSheetContent(
    unpaidCustomers: List<CustomerEntity>,
    shopName: String,
    cadence: String,
    onSelectCadence: (String) -> Unit,
    onSendWhatsApp: (CustomerEntity) -> Unit,
    onMarkSent: (CustomerEntity) -> Unit,
    onCopySummary: () -> Unit,
    onClose: () -> Unit
) {
    val strings = LocalStrings.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        Text(strings.reminderQueueTitle, style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KiranaPillChip(
                label = strings.dailyCadence,
                selected = cadence == "DAILY",
                onClick = { onSelectCadence("DAILY") },
                modifier = Modifier.weight(1f)
            )
            KiranaPillChip(
                label = strings.weeklyCadence,
                selected = cadence == "WEEKLY",
                onClick = { onSelectCadence("WEEKLY") },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (unpaidCustomers.isEmpty()) {
            RetailCard(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                borderColor = MaterialTheme.colorScheme.outline,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = strings.allClearQueueMsg,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                )
            }
        } else {
            val nextCustomer = unpaidCustomers.first()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onSendWhatsApp(nextCustomer) },
                    shape = RoundedCornerShape(KiranaTokens.PillRadius),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                        .testTag("send_next_whatsapp_button")
                ) {
                    Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.sendNextReminder, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                OutlinedButton(
                    onClick = onCopySummary,
                    shape = RoundedCornerShape(KiranaTokens.PillRadius),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("copy_summary_log_button")
                ) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.copySummaryLog, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(270.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(unpaidCustomers, key = { it.id }) { customer ->
                    RetailCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(customer.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "${formatNpr(customer.pendingBalance)} • ${customer.phone.ifBlank { "No phone" }}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                                Text(
                                    text = WhatsAppHelper.buildUdharReminderMessage(
                                        customer.name,
                                        shopName,
                                        customer.pendingBalance
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(horizontalAlignment = Alignment.End) {
                                IconButton(
                                    onClick = { onSendWhatsApp(customer) },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.Send,
                                        contentDescription = strings.whatsappBtn,
                                        tint = Color(0xFF128C7E)
                                    )
                                }
                                TextButton(
                                    onClick = { onMarkSent(customer) },
                                    contentPadding = PaddingValues(horizontal = 6.dp)
                                ) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(strings.markReminded, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(
            onClick = onClose,
            shape = RoundedCornerShape(KiranaTokens.PillRadius),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(strings.closeBtn)
        }
    }
}
