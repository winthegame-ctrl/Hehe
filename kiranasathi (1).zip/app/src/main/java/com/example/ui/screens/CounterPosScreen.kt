package com.example.ui.screens

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.ShoppingBasket
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.CustomerEntity
import com.example.data.PaymentMode
import com.example.data.ProductCategory
import com.example.data.ProductEntity
import com.example.i18n.AppLanguage
import com.example.i18n.LocalStrings
import com.example.i18n.formatNpr
import com.example.i18n.formatNumberPlain
import com.example.ui.CartLine
import com.example.ui.KiranaUiState
import com.example.ui.components.CategoryIconBadge
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KiranaPillChip
import com.example.ui.components.KiranaSearchField
import com.example.ui.components.RetailCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.KiranaTokens
import com.example.ui.theme.NumericDisplayStyle
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CounterPosScreen(
    uiState: KiranaUiState,
    onAddToCart: (ProductEntity) -> Unit,
    onDecrementCart: (Long) -> Unit,
    onClearCart: () -> Unit,
    onCompleteCheckout: (PaymentMode, Double, CustomerEntity?) -> Unit,
    onQuickAddCustomer: (String, String, (CustomerEntity) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    val language = uiState.preferences.language
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<ProductCategory?>(null) }
    var showCheckoutSheet by remember { mutableStateOf(false) }

    val filteredProducts = remember(uiState.products, searchQuery, selectedCategory) {
        uiState.products.filter { product ->
            val matchesCat = selectedCategory == null ||
                product.category.equals(selectedCategory!!.name, ignoreCase = true)
            val q = searchQuery.trim()
            val matchesSearch = q.isEmpty() ||
                product.nameEn.contains(q, ignoreCase = true) ||
                product.nameNe.contains(q, ignoreCase = true)
            matchesCat && matchesSearch
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWideCounter = maxWidth >= 820.dp

        Row(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    KiranaSearchField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = strings.searchItemsHint,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = KiranaTokens.ScreenGutter, vertical = 12.dp)
                            .testTag("pos_search_input")
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = KiranaTokens.ScreenGutter),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        item {
                            KiranaPillChip(
                                label = strings.allCategories,
                                selected = selectedCategory == null,
                                onClick = { selectedCategory = null },
                                modifier = Modifier.testTag("pos_cat_all")
                            )
                        }
                        items(ProductCategory.entries) { cat ->
                            val isSelected = selectedCategory == cat
                            KiranaPillChip(
                                label = cat.label(language),
                                selected = isSelected,
                                leadingIcon = cat.icon,
                                leadingIconTint = cat.contentColor,
                                onClick = { selectedCategory = if (isSelected) null else cat },
                                modifier = Modifier.testTag("pos_cat_${cat.name.lowercase()}")
                            )
                        }
                    }

                    if (filteredProducts.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = KiranaTokens.ScreenGutter, vertical = 20.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            EmptyStateCard(
                                icon = Icons.Rounded.ShoppingBasket,
                                message = strings.noMatchingItems,
                                actionLabel = if (searchQuery.isNotEmpty() || selectedCategory != null) {
                                    strings.clearLabel
                                } else null,
                                onAction = {
                                    searchQuery = ""
                                    selectedCategory = null
                                }
                            )
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 152.dp),
                            contentPadding = PaddingValues(
                                start = KiranaTokens.ScreenGutter,
                                end = KiranaTokens.ScreenGutter,
                                top = 2.dp,
                                bottom = if (!isWideCounter && uiState.cartItemCount > 0) 104.dp else 20.dp
                            ),
                            horizontalArrangement = Arrangement.spacedBy(KiranaTokens.CardSpacing),
                            verticalArrangement = Arrangement.spacedBy(KiranaTokens.CardSpacing),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredProducts, key = { it.id }) { product ->
                                val inCartQty = uiState.cartQuantities[product.id] ?: 0
                                PosProductTile(
                                    product = product,
                                    language = language,
                                    inCartQty = inCartQty,
                                    onTap = { onAddToCart(product) },
                                    onDecrement = { onDecrementCart(product.id) }
                                )
                            }
                        }
                    }
                }

                if (!isWideCounter) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = uiState.cartItemCount > 0,
                        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = KiranaTokens.ScreenGutter, vertical = 12.dp)
                    ) {
                        StickyCartBar(
                            itemCount = uiState.cartItemCount,
                            totalAmount = uiState.cartTotalAmount,
                            onCheckoutClick = { showCheckoutSheet = true },
                            onClearClick = onClearCart
                        )
                    }
                }
            }

            if (isWideCounter) {
                Surface(
                    modifier = Modifier
                        .width(340.dp)
                        .fillMaxHeight()
                        .padding(top = 12.dp, end = KiranaTokens.ScreenGutter, bottom = 12.dp),
                    shape = RoundedCornerShape(KiranaTokens.CardRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(KiranaTokens.BorderWidth, BorderSubtle),
                    shadowElevation = 0.dp
                ) {
                    TabletCartSidePane(
                        cartLines = uiState.cartLines,
                        totalAmount = uiState.cartTotalAmount,
                        language = language,
                        onAdd = onAddToCart,
                        onDecrement = onDecrementCart,
                        onClear = onClearCart,
                        onOpenCheckout = { showCheckoutSheet = true }
                    )
                }
            }
        }
    }

    if (showCheckoutSheet && uiState.cartLines.isNotEmpty()) {
        ModalBottomSheet(
            onDismissRequest = { showCheckoutSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            CheckoutSheetContent(
                uiState = uiState,
                onAdd = onAddToCart,
                onDecrement = onDecrementCart,
                onClear = {
                    onClearCart()
                    showCheckoutSheet = false
                },
                onQuickAddCustomer = onQuickAddCustomer,
                onFinalizeBill = { mode, cashGiven, customer ->
                    onCompleteCheckout(mode, cashGiven, customer)
                    showCheckoutSheet = false
                }
            )
        }
    }
}

@Composable
private fun PosProductTile(
    product: ProductEntity,
    language: AppLanguage,
    inCartQty: Int,
    onTap: () -> Unit,
    onDecrement: () -> Unit
) {
    val strings = LocalStrings.current
    val category = ProductCategory.fromKey(product.category)
    val displayName = if (language == AppLanguage.NE && product.nameNe.isNotBlank()) {
        product.nameNe
    } else {
        product.nameEn
    }
    val secondaryName = if (language == AppLanguage.NE) product.nameEn else product.nameNe
    val isOut = product.stockCount <= 0
    val isLow = product.stockCount in 1..5

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(KiranaTokens.CardRadius))
            .clickable(onClick = onTap)
            .testTag("pos_product_tile_${product.id}"),
        shape = RoundedCornerShape(KiranaTokens.CardRadius),
        color = if (inCartQty > 0) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
        else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (inCartQty > 0) 1.5.dp else KiranaTokens.BorderWidth,
            color = if (inCartQty > 0) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.outline
        ),
        shadowElevation = 0.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                CategoryIconBadge(
                    category = category,
                    size = 42.dp,
                    iconSize = 22.dp
                )
                if (inCartQty > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .clickable(onClick = onDecrement)
                                .testTag("pos_tile_minus_${product.id}")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.Remove,
                                    contentDescription = "Remove one",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "$inCartQty",
                                    style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.labelLarge.fontSize),
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        color = when {
                            isOut -> MaterialTheme.colorScheme.errorContainer
                            isLow -> MaterialTheme.colorScheme.tertiaryContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                    ) {
                        Text(
                            text = if (isOut) strings.outOfStock else "${product.stockCount} ${product.unitLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = when {
                                isOut -> MaterialTheme.colorScheme.error
                                isLow -> MaterialTheme.colorScheme.tertiary
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = displayName,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (secondaryName.isNotBlank() && secondaryName != displayName) {
                Text(
                    text = secondaryName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            } else {
                Spacer(modifier = Modifier.height(14.dp))
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatNpr(product.sellingPrice),
                    style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleMedium.fontSize),
                    color = MaterialTheme.colorScheme.primary
                )
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(30.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StickyCartBar(
    itemCount: Int,
    totalAmount: Double,
    onCheckoutClick: () -> Unit,
    onClearClick: () -> Unit
) {
    val strings = LocalStrings.current
    Surface(
        shape = RoundedCornerShape(KiranaTokens.CardRadius),
        color = MaterialTheme.colorScheme.primary,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(KiranaTokens.CardRadius))
            .clickable(onClick = onCheckoutClick)
            .testTag("sticky_cart_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onClearClick,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("sticky_clear_cart_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteSweep,
                        contentDescription = strings.clearCart,
                        tint = Color.White.copy(alpha = 0.9f)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "$itemCount ${strings.itemsInCart}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Text(
                        text = formatNpr(totalAmount),
                        style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                        color = Color.White
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                color = Color.White
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ReceiptLong,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.checkoutBtn,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun TabletCartSidePane(
    cartLines: List<CartLine>,
    totalAmount: Double,
    language: AppLanguage,
    onAdd: (ProductEntity) -> Unit,
    onDecrement: (Long) -> Unit,
    onClear: () -> Unit,
    onOpenCheckout: () -> Unit
) {
    val strings = LocalStrings.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.checkoutTitle,
                style = MaterialTheme.typography.titleLarge
            )
            if (cartLines.isNotEmpty()) {
                TextButton(onClick = onClear) {
                    Text(strings.clearCart, color = MaterialTheme.colorScheme.error)
                }
            }
        }
        HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 8.dp))

        if (cartLines.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = strings.emptyCartTip,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartLines, key = { it.product.id }) { line ->
                    CartLineRow(
                        line = line,
                        language = language,
                        onAdd = { onAdd(line.product) },
                        onDecrement = { onDecrement(line.product.id) }
                    )
                }
            }
            HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.totalLabel, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = formatNpr(totalAmount),
                    style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.headlineSmall.fontSize),
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onOpenCheckout,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("tablet_checkout_button")
            ) {
                Text(strings.checkoutBtn, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun CartLineRow(
    line: CartLine,
    language: AppLanguage,
    onAdd: () -> Unit,
    onDecrement: () -> Unit
) {
    val name = if (language == AppLanguage.NE && line.product.nameNe.isNotBlank()) {
        line.product.nameNe
    } else {
        line.product.nameEn
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.background)
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = name,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${formatNpr(line.product.sellingPrice)} × ${line.quantity}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onDecrement,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Rounded.Remove, contentDescription = "Decrease")
            }
            Text(
                text = "${line.quantity}",
                style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleSmall.fontSize),
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            IconButton(
                onClick = onAdd,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Increase")
            }
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = formatNpr(line.lineTotal),
            style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleSmall.fontSize),
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun CheckoutSheetContent(
    uiState: KiranaUiState,
    onAdd: (ProductEntity) -> Unit,
    onDecrement: (Long) -> Unit,
    onClear: () -> Unit,
    onQuickAddCustomer: (String, String, (CustomerEntity) -> Unit) -> Unit,
    onFinalizeBill: (PaymentMode, Double, CustomerEntity?) -> Unit
) {
    val strings = LocalStrings.current
    val language = uiState.preferences.language
    var selectedMode by remember { mutableStateOf(PaymentMode.CASH) }
    var cashGivenInput by remember(uiState.cartTotalAmount) {
        mutableStateOf(formatNumberPlain(uiState.cartTotalAmount))
    }
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(uiState.customers.firstOrNull()) }
    var showQuickCustomerForm by remember { mutableStateOf(false) }
    var newCustName by remember { mutableStateOf("") }
    var newCustPhone by remember { mutableStateOf("") }

    val total = uiState.cartTotalAmount
    val cashGiven = cashGivenInput.toDoubleOrNull() ?: 0.0
    val changeDue = cashGiven - total

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.checkoutTitle,
                style = MaterialTheme.typography.headlineSmall
            )
            TextButton(
                onClick = onClear,
                modifier = Modifier.testTag("checkout_clear_button")
            ) {
                Text(strings.clearCart, color = MaterialTheme.colorScheme.error)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            uiState.cartLines.forEach { line ->
                CartLineRow(
                    line = line,
                    language = language,
                    onAdd = { onAdd(line.product) },
                    onDecrement = { onDecrement(line.product.id) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        RetailCard(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            borderColor = MaterialTheme.colorScheme.outline,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${strings.totalLabel} (${uiState.cartItemCount})",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = formatNpr(total),
                    style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.headlineMedium.fontSize),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = strings.paymentMethod,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PaymentModeChip(
                label = strings.cashPay,
                icon = Icons.Rounded.Payments,
                selected = selectedMode == PaymentMode.CASH,
                accentColor = MaterialTheme.colorScheme.primary,
                testTag = "pay_mode_cash",
                onClick = { selectedMode = PaymentMode.CASH },
                modifier = Modifier.weight(1f)
            )
            PaymentModeChip(
                label = strings.qrPay,
                icon = Icons.Rounded.QrCode2,
                selected = selectedMode == PaymentMode.QR,
                accentColor = MaterialTheme.colorScheme.primary,
                testTag = "pay_mode_qr",
                onClick = { selectedMode = PaymentMode.QR },
                modifier = Modifier.weight(1f)
            )
            PaymentModeChip(
                label = strings.udharPay,
                icon = Icons.Rounded.PersonAdd,
                selected = selectedMode == PaymentMode.UDHAR,
                accentColor = MaterialTheme.colorScheme.tertiary,
                testTag = "pay_mode_udhar",
                onClick = { selectedMode = PaymentMode.UDHAR },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        when (selectedMode) {
            PaymentMode.CASH -> {
                OutlinedTextField(
                    value = cashGivenInput,
                    onValueChange = { cashGivenInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text(strings.cashReceivedLabel) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(KiranaTokens.InputRadius),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cash_given_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { cashGivenInput = formatNumberPlain(total) },
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        Text(strings.exactAmount, maxLines = 1)
                    }
                    listOf(100, 500, 1000).forEach { denom ->
                        OutlinedButton(
                            onClick = {
                                val next = (cashGivenInput.toDoubleOrNull() ?: 0.0) + denom
                                cashGivenInput = formatNumberPlain(next)
                            },
                            shape = RoundedCornerShape(KiranaTokens.PillRadius),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            Text("+$denom", maxLines = 1)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                RetailCard(
                    containerColor = if (changeDue >= 0) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.errorContainer,
                    borderColor = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (changeDue >= 0) strings.changeReturnLabel else strings.shortByLabel,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (changeDue >= 0) MaterialTheme.colorScheme.onPrimaryContainer
                            else MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = formatNpr(kotlin.math.abs(changeDue)),
                            style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                            color = if (changeDue >= 0) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            PaymentMode.QR -> {
                val qrPath = uiState.preferences.qrImagePath
                val qrFile = File(qrPath)
                RetailCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = strings.scanQrToPay,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        if (qrPath.isNotBlank() && qrFile.exists()) {
                            AsyncImage(
                                model = qrFile,
                                contentDescription = strings.paymentQrTitle,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(200.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.QrCode2,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = strings.noQrUploadedYet,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            PaymentMode.UDHAR -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.selectCustomerUdhar, style = MaterialTheme.typography.titleSmall)
                    TextButton(
                        onClick = { showQuickCustomerForm = !showQuickCustomerForm },
                        modifier = Modifier.testTag("checkout_quick_add_customer_btn")
                    ) {
                        Text(strings.quickAddCustomer)
                    }
                }

                if (showQuickCustomerForm) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(bottom = 10.dp)
                    ) {
                        OutlinedTextField(
                            value = newCustName,
                            onValueChange = { newCustName = it },
                            label = { Text(strings.customerNameLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(KiranaTokens.InputRadius),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newCustPhone,
                            onValueChange = { newCustPhone = it },
                            label = { Text(strings.phoneNumberLabel) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            shape = RoundedCornerShape(KiranaTokens.InputRadius),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                if (newCustName.isNotBlank()) {
                                    onQuickAddCustomer(newCustName, newCustPhone) { created ->
                                        selectedCustomer = created
                                        showQuickCustomerForm = false
                                        newCustName = ""
                                        newCustPhone = ""
                                    }
                                }
                            },
                            shape = RoundedCornerShape(KiranaTokens.PillRadius),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(strings.saveCustomerBtn)
                        }
                    }
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(uiState.customers, key = { it.id }) { customer ->
                        val isSel = selectedCustomer?.id == customer.id
                        KiranaPillChip(
                            label = "${customer.name} (${formatNpr(customer.pendingBalance)})",
                            selected = isSel,
                            selectedContainerColor = MaterialTheme.colorScheme.tertiary,
                            onClick = { selectedCustomer = customer }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
            onClick = { onFinalizeBill(selectedMode, cashGiven, selectedCustomer) },
            enabled = selectedMode != PaymentMode.UDHAR || selectedCustomer != null,
            shape = RoundedCornerShape(KiranaTokens.PillRadius),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedMode == PaymentMode.UDHAR) {
                    MaterialTheme.colorScheme.tertiary
                } else {
                    MaterialTheme.colorScheme.primary
                }
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("complete_bill_button")
        ) {
            Icon(Icons.Rounded.CheckCircle, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${strings.completeBillBtn} • ${formatNpr(total)}",
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
private fun PaymentModeChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pillShape = RoundedCornerShape(KiranaTokens.PillRadius)
    Surface(
        modifier = modifier
            .height(48.dp)
            .clip(pillShape)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = pillShape,
        color = if (selected) accentColor else MaterialTheme.colorScheme.surface,
        border = if (selected) null else BorderStroke(KiranaTokens.BorderWidth, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
