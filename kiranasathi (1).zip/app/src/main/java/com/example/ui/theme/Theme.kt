package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = ForestTealPrimary,
    onPrimary = Color.White,
    primaryContainer = SoftMintContainer,
    onPrimaryContainer = OnSoftMint,
    secondary = ForestTealPrimary,
    onSecondary = Color.White,
    secondaryContainer = SoftMintContainer,
    onSecondaryContainer = OnSoftMint,
    tertiary = AmberTextAccent,
    onTertiary = Color.White,
    tertiaryContainer = PaleAmberContainer,
    onTertiaryContainer = OnPaleAmber,
    error = SoftRedAlert,
    onError = Color.White,
    errorContainer = SoftRedContainer,
    onErrorContainer = OnSoftRed,
    background = CanvasBackground,
    onBackground = CharcoalText,
    surface = PureWhiteCard,
    onSurface = CharcoalText,
    surfaceVariant = SoftSlateSurface,
    onSurfaceVariant = SlateMutedText,
    outline = BorderHairline,
    outlineVariant = BorderSubtle
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkTealPrimary,
    onPrimary = DarkTealOnPrimary,
    primaryContainer = DarkTealContainer,
    onPrimaryContainer = DarkTextPrimary,
    secondary = Color(0xFF34D399),
    onSecondary = Color(0xFF052E16),
    secondaryContainer = Color(0xFF14532D),
    onSecondaryContainer = Color(0xFFDCFCE7),
    tertiary = Color(0xFFFBBF24),
    onTertiary = Color(0xFF451A03),
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = Color(0xFFFEF3C7),
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2),
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkOutline,
    outlineVariant = DarkOutline
)

object KiranaTokens {
    val CardRadius = 14.dp
    val InputRadius = 14.dp
    val SheetRadius = 20.dp
    val PillRadius = 999.dp
    val BorderWidth = 1.dp
    val ScreenGutter = 14.dp
    val CardSpacing = 12.dp
    val CardPadding = 14.dp
}

val KiranaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(22.dp)
)

@Composable
fun KiranaSathiTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = KiranaShapes,
        content = content
    )
}
