package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.i18n.LocalStrings
import com.example.ui.BackupFormat
import com.example.ui.KiranaUiState
import com.example.ui.components.FullScreenQrDialog
import com.example.ui.components.LanguageTogglePill
import com.example.ui.components.RetailCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.KiranaTokens
import com.example.util.DateTimeHelper
import java.io.File

@Composable
fun MoreSettingsScreen(
    uiState: KiranaUiState,
    onToggleLanguage: () -> Unit,
    onUploadQrUri: (Uri) -> Unit,
    onRemoveQr: () -> Unit,
    onExportBackup: (Uri, BackupFormat) -> Unit,
    onImportBackup: (Uri) -> Unit,
    onUpdateShopName: (String) -> Unit,
    onChangePin: (String) -> Unit,
    onLockApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    var showFullQrDialog by remember { mutableStateOf(false) }
    var showShopNameDialog by remember { mutableStateOf(false) }
    var showChangePinDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onUploadQrUri(uri)
    }

    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) onExportBackup(uri, BackupFormat.JSON)
    }

    val exportCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) onExportBackup(uri, BackupFormat.CSV)
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onImportBackup(uri)
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(KiranaTokens.ScreenGutter),
        verticalArrangement = Arrangement.spacedBy(KiranaTokens.CardSpacing)
    ) {
        item {
            RetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.QrCode2,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.paymentQrTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = strings.paymentQrSubtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val qrPath = uiState.preferences.qrImagePath
                    val qrFile = File(qrPath)
                    if (qrPath.isNotBlank() && qrFile.exists()) {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = qrFile,
                                contentDescription = strings.paymentQrTitle,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(170.dp)
                                    .clip(RoundedCornerShape(KiranaTokens.CardRadius))
                                    .border(1.dp, BorderSubtle, RoundedCornerShape(KiranaTokens.CardRadius))
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(KiranaTokens.PillRadius),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("upload_qr_button")
                        ) {
                            Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.uploadQrBtn, maxLines = 1)
                        }
                        if (qrPath.isNotBlank() && qrFile.exists()) {
                            OutlinedButton(
                                onClick = { showFullQrDialog = true },
                                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("show_full_qr_button")
                            ) {
                                Icon(Icons.Rounded.Fullscreen, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(strings.showFullQrBtn, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = onRemoveQr,
                                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                                modifier = Modifier.height(46.dp)
                            ) {
                                Icon(
                                    Icons.Rounded.DeleteOutline,
                                    contentDescription = strings.removeQrBtn,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            RetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Backup,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(strings.backupRestoreTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = strings.backupRestoreSubtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                exportJsonLauncher.launch("kiranasaathi_backup_${DateTimeHelper.backupTimestampTag()}.json")
                            },
                            shape = RoundedCornerShape(KiranaTokens.PillRadius),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("export_json_button")
                        ) {
                            Text(strings.exportJsonBtn, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = {
                                exportCsvLauncher.launch("kiranasaathi_backup_${DateTimeHelper.backupTimestampTag()}.csv")
                            },
                            shape = RoundedCornerShape(KiranaTokens.PillRadius),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("export_csv_button")
                        ) {
                            Text(strings.exportCsvBtn, maxLines = 1)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            importBackupLauncher.launch(
                                arrayOf("application/json", "text/csv", "text/comma-separated-values", "*/*")
                            )
                        },
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("import_restore_button")
                    ) {
                        Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.importRestoreBtn)
                    }
                }
            }
        }

        item {
            RetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(strings.storeSecurityTitle, style = MaterialTheme.typography.titleMedium)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Translate,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.languageSettingLabel, style = MaterialTheme.typography.bodyLarge)
                        }
                        LanguageTogglePill(
                            language = uiState.preferences.language,
                            onToggle = onToggleLanguage
                        )
                    }

                    OutlinedButton(
                        onClick = { showShopNameDialog = true },
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("edit_shop_name_button")
                    ) {
                        Icon(Icons.Rounded.Storefront, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${strings.editShopNameBtn}: ${uiState.preferences.shopName}", maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = { showChangePinDialog = true },
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("change_pin_button")
                    ) {
                        Icon(Icons.Rounded.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.changePinBtn)
                    }

                    Button(
                        onClick = onLockApp,
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("lock_app_button")
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.lockAppBtn)
                    }
                }
            }
        }
    }

    if (showFullQrDialog) {
        FullScreenQrDialog(
            shopName = uiState.preferences.shopName,
            qrImagePath = uiState.preferences.qrImagePath,
            onDismiss = { showFullQrDialog = false }
        )
    }

    if (showShopNameDialog) {
        var nameInput by remember(uiState.preferences.shopName) {
            mutableStateOf(uiState.preferences.shopName)
        }
        AlertDialog(
            onDismissRequest = { showShopNameDialog = false },
            title = { Text(strings.editShopNameBtn) },
            text = {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text(strings.shopNameLabel) },
                    singleLine = true,
                    shape = RoundedCornerShape(KiranaTokens.InputRadius)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateShopName(nameInput)
                        showShopNameDialog = false
                    },
                    shape = RoundedCornerShape(KiranaTokens.PillRadius)
                ) { Text(strings.saveItemBtn) }
            },
            dismissButton = {
                TextButton(onClick = { showShopNameDialog = false }) { Text(strings.cancelBtn) }
            }
        )
    }

    if (showChangePinDialog) {
        var newPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showChangePinDialog = false },
            title = { Text(strings.changePinBtn) },
            text = {
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { ch ->
                        val digits = ch.filter { it.isDigit() }
                        if (digits.length <= 4) newPin = digits
                    },
                    label = { Text(strings.enter4DigitPin) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    shape = RoundedCornerShape(KiranaTokens.InputRadius)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onChangePin(newPin)
                        showChangePinDialog = false
                    },
                    enabled = newPin.length == 4,
                    shape = RoundedCornerShape(KiranaTokens.PillRadius)
                ) { Text(strings.saveItemBtn) }
            },
            dismissButton = {
                TextButton(onClick = { showChangePinDialog = false }) { Text(strings.cancelBtn) }
            }
        )
    }
}
