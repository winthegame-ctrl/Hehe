package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.CashAdjustmentEntity
import com.example.data.CashAdjustmentType
import com.example.data.PaymentMode
import com.example.data.SaleEntity
import com.example.i18n.LocalStrings
import com.example.i18n.formatNpr
import com.example.ui.KiranaUiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KiranaPillChip
import com.example.ui.components.RetailCard
import com.example.ui.theme.KiranaTokens
import com.example.ui.theme.NumericDisplayStyle
import com.example.util.DateTimeHelper

private enum class ActivityFilter {
    ALL,
    SALES,
    DRAWER
}

private sealed class WalletActivityItem(val timestamp: Long) {
    class SaleItem(val sale: SaleEntity) : WalletActivityItem(sale.timestamp)
    class AdjustmentItem(val adjustment: CashAdjustmentEntity) : WalletActivityItem(adjustment.timestamp)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
    uiState: KiranaUiState,
    onAddCashAdjustment: (CashAdjustmentType, Double, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    val summary = uiState.walletSummary
    var filter by remember { mutableStateOf(ActivityFilter.ALL) }
    var showDrawerSheet by remember { mutableStateOf(false) }

    val activityItems = remember(uiState.sales, uiState.cashAdjustments, filter) {
        val salesItems = if (filter != ActivityFilter.DRAWER) {
            uiState.sales.map { WalletActivityItem.SaleItem(it) }
        } else emptyList()
        val drawerItems = if (filter != ActivityFilter.SALES) {
            uiState.cashAdjustments.map { WalletActivityItem.AdjustmentItem(it) }
        } else emptyList()
        (salesItems + drawerItems).sortedByDescending { it.timestamp }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(KiranaTokens.ScreenGutter),
        verticalArrangement = Arrangement.spacedBy(KiranaTokens.CardSpacing)
    ) {
        // Hero Cash in Drawer Card (Flat #0F6663 Forest Teal)
        item {
            Surface(
                shape = RoundedCornerShape(KiranaTokens.CardRadius),
                color = MaterialTheme.colorScheme.primary,
                shadowElevation = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.AccountBalanceWallet,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.9f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.cashInDrawerLabel,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(KiranaTokens.PillRadius),
                            color = Color.White.copy(alpha = 0.16f),
                            onClick = { showDrawerSheet = true },
                            modifier = Modifier.testTag("wallet_cash_in_out_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.SwapVert,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = strings.cashInOutBtn,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = formatNpr(summary.cashInDrawer),
                        style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.displaySmall.fontSize),
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BreakdownPill(
                            label = strings.cashSalesLabel,
                            value = formatNpr(summary.todayCashSales),
                            modifier = Modifier.weight(1f)
                        )
                        BreakdownPill(
                            label = strings.qrSalesLabel,
                            value = formatNpr(summary.todayQrSales),
                            modifier = Modifier.weight(1f)
                        )
                        BreakdownPill(
                            label = strings.udharSalesLabel,
                            value = formatNpr(summary.todayUdharSales),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(KiranaTokens.CardSpacing)
            ) {
                MetricTile(
                    title = strings.todaySalesLabel,
                    value = formatNpr(summary.todayTotalSales),
                    icon = Icons.Rounded.ReceiptLong,
                    accent = MaterialTheme.colorScheme.primary,
                    container = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = strings.estimatedProfitLabel,
                    value = formatNpr(summary.todayEstimatedProfit),
                    icon = Icons.Rounded.TrendingUp,
                    accent = MaterialTheme.colorScheme.primary,
                    container = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            RetailCard(
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                borderColor = MaterialTheme.colorScheme.outline,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.totalPendingUdhar,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Text(
                        text = formatNpr(summary.totalPendingUdhar),
                        style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
        }

        item {
            Text(
                text = strings.recentTransactionsTitle,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KiranaPillChip(
                    label = strings.allTransactions,
                    selected = filter == ActivityFilter.ALL,
                    onClick = { filter = ActivityFilter.ALL }
                )
                KiranaPillChip(
                    label = strings.salesOnly,
                    selected = filter == ActivityFilter.SALES,
                    onClick = { filter = ActivityFilter.SALES }
                )
                KiranaPillChip(
                    label = strings.drawerOnly,
                    selected = filter == ActivityFilter.DRAWER,
                    onClick = { filter = ActivityFilter.DRAWER }
                )
            }
        }

        if (activityItems.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.ReceiptLong,
                    message = strings.noTransactionsEmpty
                )
            }
        } else {
            items(activityItems, key = { item ->
                when (item) {
                    is WalletActivityItem.SaleItem -> "sale_${item.sale.id}"
                    is WalletActivityItem.AdjustmentItem -> "adj_${item.adjustment.id}"
                }
            }) { item ->
                when (item) {
                    is WalletActivityItem.SaleItem -> SaleActivityRow(item.sale)
                    is WalletActivityItem.AdjustmentItem -> DrawerAdjustmentRow(item.adjustment)
                }
            }
        }
    }

    if (showDrawerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showDrawerSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            DrawerAdjustmentSheetContent(
                onSave = { type, amount, note ->
                    onAddCashAdjustment(type, amount, note)
                    showDrawerSheet = false
                },
                onCancel = { showDrawerSheet = false }
            )
        }
    }
}

@Composable
private fun BreakdownPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color.White.copy(alpha = 0.14f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.82f),
                maxLines = 1
            )
            Text(
                text = value,
                style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.labelLarge.fontSize),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    value: String,
    icon: ImageVector,
    accent: Color,
    container: Color,
    modifier: Modifier = Modifier
) {
    RetailCard(
        modifier = modifier,
        containerColor = container,
        borderColor = MaterialTheme.colorScheme.outline
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = accent)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                color = accent
            )
        }
    }
}

@Composable
private fun SaleActivityRow(sale: SaleEntity) {
    val strings = LocalStrings.current
    val mode = PaymentMode.entries.firstOrNull { it.name == sale.paymentMode } ?: PaymentMode.CASH
    val badgeColor = when (mode) {
        PaymentMode.CASH, PaymentMode.QR -> MaterialTheme.colorScheme.primary
        PaymentMode.UDHAR -> MaterialTheme.colorScheme.tertiary
    }
    val modeLabel = when (mode) {
        PaymentMode.CASH -> strings.cashSalesLabel
        PaymentMode.QR -> strings.qrSalesLabel
        PaymentMode.UDHAR -> strings.udharSalesLabel
    }

    RetailCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (mode) {
                        PaymentMode.CASH -> Icons.Rounded.Payments
                        PaymentMode.QR -> Icons.Rounded.QrCode2
                        PaymentMode.UDHAR -> Icons.Rounded.ReceiptLong
                    },
                    contentDescription = modeLabel,
                    tint = badgeColor
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = sale.summaryText.ifBlank { modeLabel },
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val subLine = buildString {
                    append(modeLabel)
                    if (!sale.customerNameSnapshot.isNullOrBlank()) {
                        append(" • ${sale.customerNameSnapshot}")
                    }
                    append(" • ${DateTimeHelper.formatTimeOrDate(sale.timestamp)}")
                }
                Text(
                    text = subLine,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = formatNpr(sale.totalAmount),
                style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleMedium.fontSize),
                color = badgeColor
            )
        }
    }
}

@Composable
private fun DrawerAdjustmentRow(entry: CashAdjustmentEntity) {
    val strings = LocalStrings.current
    val isIn = entry.type == CashAdjustmentType.CASH_IN.name
    val color = if (isIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error

    RetailCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isIn) Icons.Rounded.ArrowDownward else Icons.Rounded.ArrowUpward,
                    contentDescription = null,
                    tint = color
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.note.ifBlank { if (isIn) strings.cashInLabel else strings.cashOutLabel },
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = DateTimeHelper.formatTimeOrDate(entry.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = (if (isIn) "+" else "-") + formatNpr(entry.amount),
                style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleMedium.fontSize),
                color = color
            )
        }
    }
}

@Composable
private fun DrawerAdjustmentSheetContent(
    onSave: (CashAdjustmentType, Double, String) -> Unit,
    onCancel: () -> Unit
) {
    val strings = LocalStrings.current
    var type by remember { mutableStateOf(CashAdjustmentType.CASH_IN) }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val amount = amountText.toDoubleOrNull() ?: 0.0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(strings.cashInOutBtn, style = MaterialTheme.typography.headlineSmall)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KiranaPillChip(
                label = strings.cashInLabel,
                selected = type == CashAdjustmentType.CASH_IN,
                onClick = { type = CashAdjustmentType.CASH_IN },
                modifier = Modifier.weight(1f)
            )
            KiranaPillChip(
                label = strings.cashOutLabel,
                selected = type == CashAdjustmentType.CASH_OUT,
                selectedContainerColor = MaterialTheme.colorScheme.error,
                onClick = { type = CashAdjustmentType.CASH_OUT },
                modifier = Modifier.weight(1f)
            )
        }
        OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text(strings.amountNprLabel) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("drawer_amount_input")
        )
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text(strings.noteOptionalLabel) },
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) { Text(strings.cancelBtn) }
            Button(
                onClick = { onSave(type, amount, note) },
                enabled = amount > 0.0,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (type == CashAdjustmentType.CASH_IN) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.error
                    }
                ),
                modifier = Modifier
                    .weight(2f)
                    .height(50.dp)
                    .testTag("save_drawer_adjustment_button")
            ) { Text(strings.saveAdjustmentBtn) }
        }
    }
}
