package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Daylight Utility Minimalist Palette — KiranaSathi
val ForestTealPrimary = Color(0xFF0F6663)
val ForestTealDark = Color(0xFF0A4B49)
val SoftMintContainer = Color(0xFFE8F6F2)
val OnSoftMint = Color(0xFF0B4643)

val EmeraldAccent = Color(0xFF0F6663)
val PaleAmberContainer = Color(0xFFFEF6DC)
val AmberTextAccent = Color(0xFFB45309)
val OnPaleAmber = Color(0xFF5C3A05)

val SoftRedAlert = Color(0xFFD32F2F)
val SoftRedContainer = Color(0xFFFDECEC)
val OnSoftRed = Color(0xFF7F1D1D)

val CanvasBackground = Color(0xFFF7F9F9)
val PureWhiteCard = Color(0xFFFFFFFF)
val SoftSlateSurface = Color(0xFFF1F5F5)
val BorderHairline = Color(0xFFD8E2E1)
val BorderSubtle = Color(0xFFE2E8F0)

val CharcoalText = Color(0xFF1E293B)
val SlateMutedText = Color(0xFF64748B)

// Dark Theme Fallback Tokens
val DarkTealPrimary = Color(0xFF4FD1C5)
val DarkTealOnPrimary = Color(0xFF003737)
val DarkTealContainer = Color(0xFF0A4F52)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF283548)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)
