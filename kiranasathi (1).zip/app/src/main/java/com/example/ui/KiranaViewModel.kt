package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BackupManager
import com.example.data.CashAdjustmentEntity
import com.example.data.CashAdjustmentType
import com.example.data.CustomerEntity
import com.example.data.KiranaDatabase
import com.example.data.KiranaRepository
import com.example.data.PaymentMode
import com.example.data.PreferencesStore
import com.example.data.ProductCategory
import com.example.data.ProductEntity
import com.example.data.ReminderLogEntity
import com.example.data.SaleEntity
import com.example.data.ShopPreferences
import com.example.data.UdharEntryType
import com.example.data.UdharTransactionEntity
import com.example.i18n.AppLanguage
import com.example.i18n.EnglishStrings
import com.example.i18n.NepaliStrings
import com.example.i18n.formatNpr
import com.example.util.DateTimeHelper
import com.example.util.QrStorageHelper
import com.example.util.SecurityUtils
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AuthGateState {
    LOADING,
    NEEDS_SETUP,
    LOCKED,
    UNLOCKED
}

enum class BackupFormat {
    JSON,
    CSV
}

data class CartLine(
    val product: ProductEntity,
    val quantity: Int
) {
    val lineTotal: Double get() = product.sellingPrice * quantity
    val lineCost: Double get() = product.costPrice * quantity
}

data class WalletSummary(
    val cashInDrawer: Double = 0.0,
    val todayTotalSales: Double = 0.0,
    val todayCashSales: Double = 0.0,
    val todayQrSales: Double = 0.0,
    val todayUdharSales: Double = 0.0,
    val todayEstimatedProfit: Double = 0.0,
    val totalPendingUdhar: Double = 0.0,
    val totalAllTimeSales: Double = 0.0
)

data class KiranaUiState(
    val authState: AuthGateState = AuthGateState.LOADING,
    val preferences: ShopPreferences = ShopPreferences(),
    val products: List<ProductEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val sales: List<SaleEntity> = emptyList(),
    val udharTransactions: List<UdharTransactionEntity> = emptyList(),
    val cashAdjustments: List<CashAdjustmentEntity> = emptyList(),
    val reminderLogs: List<ReminderLogEntity> = emptyList(),
    val cartQuantities: Map<Long, Int> = emptyMap()
) {
    val cartLines: List<CartLine>
        get() = cartQuantities.mapNotNull { (productId, qty) ->
            val product = products.firstOrNull { it.id == productId }
            if (product != null && qty > 0) CartLine(product, qty) else null
        }

    val cartItemCount: Int get() = cartLines.sumOf { it.quantity }
    val cartTotalAmount: Double get() = cartLines.sumOf { it.lineTotal }
    val cartEstimatedProfit: Double
        get() = cartLines.sumOf { line ->
            val unitProfit = if (line.product.costPrice > 0.0) {
                line.product.sellingPrice - line.product.costPrice
            } else {
                line.product.sellingPrice * 0.12
            }
            unitProfit * line.quantity
        }

    val lowStockCount: Int get() = products.count { it.stockCount <= 5 }

    val unpaidCustomers: List<CustomerEntity>
        get() = customers.filter { it.pendingBalance > 0.0 }
            .sortedWith(
                compareBy<CustomerEntity> { it.lastRemindedAt ?: 0L }
                    .thenByDescending { it.pendingBalance }
            )

    val walletSummary: WalletSummary
        get() {
            val todayStart = DateTimeHelper.startOfTodayMillis()
            val todaySales = sales.filter { it.timestamp >= todayStart }
            val todayCash = todaySales.filter { it.paymentMode == PaymentMode.CASH.name }.sumOf { it.totalAmount }
            val todayQr = todaySales.filter { it.paymentMode == PaymentMode.QR.name }.sumOf { it.totalAmount }
            val todayUdhar = todaySales.filter { it.paymentMode == PaymentMode.UDHAR.name }.sumOf { it.totalAmount }
            val allCashSales = sales.filter { it.paymentMode == PaymentMode.CASH.name }.sumOf { it.totalAmount }
            val udharCollected = udharTransactions
                .filter { it.entryType == UdharEntryType.PAYMENT_RECEIVED.name }
                .sumOf { it.amount }
            val cashIn = cashAdjustments
                .filter { it.type == CashAdjustmentType.CASH_IN.name }
                .sumOf { it.amount }
            val cashOut = cashAdjustments
                .filter { it.type == CashAdjustmentType.CASH_OUT.name }
                .sumOf { it.amount }

            return WalletSummary(
                cashInDrawer = (allCashSales + udharCollected + cashIn - cashOut).coerceAtLeast(0.0),
                todayTotalSales = todaySales.sumOf { it.totalAmount },
                todayCashSales = todayCash,
                todayQrSales = todayQr,
                todayUdharSales = todayUdhar,
                todayEstimatedProfit = todaySales.sumOf { it.estimatedProfit },
                totalPendingUdhar = customers.sumOf { it.pendingBalance },
                totalAllTimeSales = sales.sumOf { it.totalAmount }
            )
        }
}

class KiranaViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KiranaRepository

    init {
        val db = KiranaDatabase.getInstance(application)
        val prefs = PreferencesStore(application)
        repository = KiranaRepository(db.kiranaDao(), prefs)
        viewModelScope.launch {
            repository.ensureStarterCatalogSeeded()
        }
    }

    private val cartQuantitiesFlow = MutableStateFlow<Map<Long, Int>>(emptyMap())

    private val _toastMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toastMessages: SharedFlow<String> = _toastMessages.asSharedFlow()

    private val baseDataFlow = combine(
        repository.preferences,
        repository.products,
        repository.customers,
        repository.sales,
        repository.udharTransactions
    ) { prefs, products, customers, sales, udharTx ->
        Quint(prefs, products, customers, sales, udharTx)
    }

    val uiState: StateFlow<KiranaUiState> = combine(
        baseDataFlow,
        repository.cashAdjustments,
        repository.reminderLogs,
        cartQuantitiesFlow
    ) { base, cashAdj, reminders, cart ->
        val authState = when {
            base.first.pinHash.isBlank() -> AuthGateState.NEEDS_SETUP
            base.first.isLocked -> AuthGateState.LOCKED
            else -> AuthGateState.UNLOCKED
        }
        KiranaUiState(
            authState = authState,
            preferences = base.first,
            products = base.second,
            customers = base.third,
            sales = base.fourth,
            udharTransactions = base.fifth,
            cashAdjustments = cashAdj,
            reminderLogs = reminders,
            cartQuantities = cart
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = KiranaUiState()
    )

    private fun strings() = if (uiState.value.preferences.language == AppLanguage.NE) {
        NepaliStrings
    } else {
        EnglishStrings
    }

    fun emitMessage(message: String) {
        _toastMessages.tryEmit(message)
    }

    // Security & Profile
    fun setupMasterPin(pin: String, shopName: String) {
        viewModelScope.launch {
            repository.saveInitialPin(SecurityUtils.hashPin(pin), shopName)
        }
    }

    fun unlockWithPin(pin: String): Boolean {
        val expected = uiState.value.preferences.pinHash
        val matches = SecurityUtils.hashPin(pin) == expected
        if (matches) {
            viewModelScope.launch { repository.setLocked(false) }
        }
        return matches
    }

    fun lockApp() {
        viewModelScope.launch { repository.setLocked(true) }
    }

    fun changeMasterPin(newPin: String) {
        viewModelScope.launch {
            repository.updatePin(SecurityUtils.hashPin(newPin))
            emitMessage(strings().newPinSavedMsg)
        }
    }

    fun toggleLanguage() {
        val next = if (uiState.value.preferences.language == AppLanguage.EN) {
            AppLanguage.NE
        } else {
            AppLanguage.EN
        }
        viewModelScope.launch { repository.setLanguage(next) }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { repository.setLanguage(language) }
    }

    fun updateShopName(name: String) {
        viewModelScope.launch { repository.setShopName(name) }
    }

    // Cart & POS
    fun addToCart(product: ProductEntity) {
        val current = cartQuantitiesFlow.value.toMutableMap()
        val existing = current[product.id] ?: 0
        current[product.id] = existing + 1
        cartQuantitiesFlow.value = current
    }

    fun decrementCart(productId: Long) {
        val current = cartQuantitiesFlow.value.toMutableMap()
        val existing = current[productId] ?: 0
        if (existing <= 1) {
            current.remove(productId)
        } else {
            current[productId] = existing - 1
        }
        cartQuantitiesFlow.value = current
    }

    fun clearCart() {
        cartQuantitiesFlow.value = emptyMap()
    }

    fun completeCheckout(
        paymentMode: PaymentMode,
        cashReceived: Double,
        customer: CustomerEntity?
    ) {
        val state = uiState.value
        val lines = state.cartLines
        if (lines.isEmpty()) return
        if (paymentMode == PaymentMode.UDHAR && customer == null) {
            emitMessage(strings().selectCustomerError)
            return
        }

        val total = state.cartTotalAmount
        val profit = state.cartEstimatedProfit
        val itemCount = state.cartItemCount
        val summary = lines.take(3).joinToString(", ") { "${it.product.nameEn} x${it.quantity}" } +
            if (lines.size > 3) " +${lines.size - 3}" else ""
        val change = if (paymentMode == PaymentMode.CASH && cashReceived > total) {
            cashReceived - total
        } else {
            0.0
        }

        viewModelScope.launch {
            val sale = SaleEntity(
                paymentMode = paymentMode.name,
                customerId = customer?.id,
                customerNameSnapshot = customer?.name,
                totalAmount = total,
                estimatedProfit = profit,
                cashReceived = if (paymentMode == PaymentMode.CASH) cashReceived else total,
                changeGiven = change,
                itemCount = itemCount,
                summaryText = summary
            )
            repository.completeCheckout(
                sale = sale,
                cartLines = lines.map { it.product to it.quantity },
                udharNote = summary
            )
            cartQuantitiesFlow.value = emptyMap()
            emitMessage(strings().saleCompletedMsg)
        }
    }

    // Inventory
    fun saveProduct(
        existingId: Long,
        nameEn: String,
        nameNe: String,
        category: ProductCategory,
        sellingPrice: Double,
        costPrice: Double,
        stockCount: Int,
        unitLabel: String
    ) {
        viewModelScope.launch {
            repository.saveProduct(
                ProductEntity(
                    id = existingId,
                    nameEn = nameEn.trim(),
                    nameNe = nameNe.trim().ifBlank { nameEn.trim() },
                    category = category.name,
                    sellingPrice = sellingPrice.coerceAtLeast(0.0),
                    costPrice = costPrice.coerceAtLeast(0.0),
                    stockCount = stockCount.coerceAtLeast(0),
                    unitLabel = unitLabel.trim().ifBlank { "pcs" }
                )
            )
        }
    }

    fun deleteProduct(productId: Long) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
            val current = cartQuantitiesFlow.value.toMutableMap()
            current.remove(productId)
            cartQuantitiesFlow.value = current
        }
    }

    fun refillStock(productId: Long, delta: Int) {
        if (delta == 0) return
        viewModelScope.launch {
            repository.refillProductStock(productId, delta)
        }
    }

    // Udhar & Reminders
    fun addCustomer(
        name: String,
        phone: String,
        initialUdhar: Double = 0.0,
        note: String = "",
        onCreated: ((CustomerEntity) -> Unit)? = null
    ) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val id = repository.addCustomer(name, phone, initialUdhar, note)
            if (onCreated != null) {
                onCreated(
                    CustomerEntity(
                        id = id,
                        name = name.trim(),
                        phone = phone.trim(),
                        pendingBalance = initialUdhar.coerceAtLeast(0.0)
                    )
                )
            }
        }
    }

    fun addManualUdhar(customerId: Long, amount: Double, note: String) {
        if (amount <= 0.0) return
        viewModelScope.launch {
            repository.addManualUdhar(customerId, amount, note.ifBlank { "Manual Udhar" })
        }
    }

    fun receiveUdharPayment(customerId: Long, amount: Double, note: String) {
        if (amount <= 0.0) return
        viewModelScope.launch {
            repository.receiveUdharPayment(customerId, amount, note.ifBlank { "Cash received" })
        }
    }

    fun sendWhatsAppReminder(context: Context, customer: CustomerEntity) {
        val shopName = uiState.value.preferences.shopName
        WhatsAppHelper.launchWhatsAppReminder(context, customer, shopName)
        viewModelScope.launch {
            repository.logWhatsAppReminder(customer)
        }
    }

    fun markReminderSent(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.logWhatsAppReminder(customer)
        }
    }

    fun setReminderCadence(cadence: String) {
        viewModelScope.launch {
            repository.setReminderCadence(cadence)
        }
    }

    fun buildReminderSummaryText(): String {
        val state = uiState.value
        val shopName = state.preferences.shopName
        val unpaid = state.unpaidCustomers
        if (unpaid.isEmpty()) return "$shopName: 0 pending Udhar."
        val header = "$shopName - Udhar Reminder Summary (${state.preferences.reminderCadence})\n" +
            "Total Pending: ${formatNpr(unpaid.sumOf { it.pendingBalance })}\n"
        val lines = unpaid.mapIndexed { idx, c ->
            "${idx + 1}. ${c.name} (${c.phone.ifBlank { "No phone" }}): ${formatNpr(c.pendingBalance)}"
        }.joinToString("\n")
        return header + lines
    }

    // Cash Drawer
    fun addCashAdjustment(type: CashAdjustmentType, amount: Double, note: String) {
        if (amount <= 0.0) return
        viewModelScope.launch {
            repository.addCashAdjustment(type, amount, note)
        }
    }

    // Payment QR
    fun saveQrFromUri(uri: Uri) {
        viewModelScope.launch {
            val savedPath = withContext(Dispatchers.IO) {
                QrStorageHelper.copyUriToInternalQrFile(getApplication(), uri)
            }
            if (savedPath != null) {
                repository.setQrImagePath(savedPath)
                emitMessage(strings().qrSavedMsg)
            }
        }
    }

    fun removeQr() {
        val currentPath = uiState.value.preferences.qrImagePath
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                QrStorageHelper.deleteInternalQrFile(currentPath)
            }
            repository.setQrImagePath("")
        }
    }

    // Backup & Restore
    fun exportBackupToUri(uri: Uri, format: BackupFormat) {
        viewModelScope.launch {
            val result = runCatching {
                val snapshot = repository.exportSnapshot()
                val content = when (format) {
                    BackupFormat.JSON -> BackupManager.toJsonString(snapshot)
                    BackupFormat.CSV -> BackupManager.toCsvString(snapshot)
                }
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    } ?: error("Cannot write to selected file")
                }
            }
            if (result.isSuccess) {
                emitMessage(strings().backupSuccessMsg)
            } else {
                emitMessage(result.exceptionOrNull()?.localizedMessage ?: "Export failed")
            }
        }
    }

    fun importBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                val rawText = withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                        input.bufferedReader(Charsets.UTF_8).readText()
                    } ?: error("Cannot read selected file")
                }
                val snapshot = BackupManager.parseBackupContent(rawText)
                repository.restoreSnapshot(snapshot)
            }
            if (result.isSuccess) {
                emitMessage(strings().restoreSuccessMsg)
            } else {
                emitMessage(result.exceptionOrNull()?.localizedMessage ?: "Invalid backup file")
            }
        }
    }
}

private data class Quint<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)
