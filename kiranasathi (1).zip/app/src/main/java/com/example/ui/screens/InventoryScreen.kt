package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddBox
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ProductCategory
import com.example.data.ProductEntity
import com.example.i18n.AppLanguage
import com.example.i18n.LocalStrings
import com.example.i18n.formatNpr
import com.example.i18n.formatNumberPlain
import com.example.ui.KiranaUiState
import com.example.ui.components.CategoryIconBadge
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KiranaPillChip
import com.example.ui.components.KiranaSearchField
import com.example.ui.components.RetailCard
import com.example.ui.theme.KiranaTokens
import com.example.ui.theme.NumericDisplayStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    uiState: KiranaUiState,
    onSaveProduct: (Long, String, String, ProductCategory, Double, Double, Int, String) -> Unit,
    onDeleteProduct: (Long) -> Unit,
    onRefillStock: (Long, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalStrings.current
    val language = uiState.preferences.language

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<ProductCategory?>(null) }
    var refillTarget by remember { mutableStateOf<ProductEntity?>(null) }
    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showAddEditor by remember { mutableStateOf(false) }

    val filtered = remember(uiState.products, searchQuery, selectedCategory) {
        uiState.products.filter { item ->
            val catMatch = selectedCategory == null ||
                item.category.equals(selectedCategory!!.name, ignoreCase = true)
            val q = searchQuery.trim()
            val textMatch = q.isEmpty() ||
                item.nameEn.contains(q, ignoreCase = true) ||
                item.nameNe.contains(q, ignoreCase = true)
            catMatch && textMatch
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = KiranaTokens.ScreenGutter, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RetailCard(
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Inventory2,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "${uiState.products.size}",
                            style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = strings.totalItemsLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            RetailCard(
                modifier = Modifier.weight(1f),
                containerColor = if (uiState.lowStockCount > 0) MaterialTheme.colorScheme.tertiaryContainer
                else MaterialTheme.colorScheme.surface,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WarningAmber,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "${uiState.lowStockCount}",
                            style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = strings.lowStockAlertsLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Button(
                onClick = {
                    editingProduct = null
                    showAddEditor = true
                },
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .height(54.dp)
                    .testTag("add_inventory_item_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text(strings.addItemBtn, maxLines = 1)
            }
        }

        KiranaSearchField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = strings.searchItemsHint,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = KiranaTokens.ScreenGutter)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = KiranaTokens.ScreenGutter, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                KiranaPillChip(
                    label = strings.allCategories,
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null }
                )
            }
            items(ProductCategory.entries) { cat ->
                val isSelected = selectedCategory == cat
                KiranaPillChip(
                    label = cat.label(language),
                    selected = isSelected,
                    leadingIcon = cat.icon,
                    leadingIconTint = cat.contentColor,
                    onClick = { selectedCategory = if (isSelected) null else cat }
                )
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = KiranaTokens.ScreenGutter, vertical = 12.dp)
            ) {
                EmptyStateCard(
                    icon = Icons.Rounded.Inventory2,
                    message = strings.noMatchingItems,
                    actionLabel = if (searchQuery.isNotEmpty() || selectedCategory != null) {
                        strings.clearLabel
                    } else strings.addItemBtn,
                    onAction = {
                        if (searchQuery.isNotEmpty() || selectedCategory != null) {
                            searchQuery = ""
                            selectedCategory = null
                        } else {
                            editingProduct = null
                            showAddEditor = true
                        }
                    }
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = KiranaTokens.ScreenGutter, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(KiranaTokens.CardSpacing),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { product ->
                    InventoryItemCard(
                        product = product,
                        language = language,
                        onRefill = { refillTarget = product },
                        onEdit = {
                            editingProduct = product
                            showAddEditor = true
                        }
                    )
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }

    refillTarget?.let { target ->
        ModalBottomSheet(
            onDismissRequest = { refillTarget = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            SmartRefillSheetContent(
                product = target,
                language = language,
                onConfirmRefill = { delta ->
                    onRefillStock(target.id, delta)
                    refillTarget = null
                },
                onDismiss = { refillTarget = null }
            )
        }
    }

    if (showAddEditor) {
        ModalBottomSheet(
            onDismissRequest = { showAddEditor = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            ProductEditorSheetContent(
                existing = editingProduct,
                language = language,
                onSave = { nameEn, nameNe, cat, sell, cost, stock, unit ->
                    onSaveProduct(
                        editingProduct?.id ?: 0L,
                        nameEn,
                        nameNe,
                        cat,
                        sell,
                        cost,
                        stock,
                        unit
                    )
                    showAddEditor = false
                },
                onDelete = editingProduct?.let { existing ->
                    {
                        onDeleteProduct(existing.id)
                        showAddEditor = false
                    }
                },
                onCancel = { showAddEditor = false }
            )
        }
    }
}

@Composable
private fun InventoryItemCard(
    product: ProductEntity,
    language: AppLanguage,
    onRefill: () -> Unit,
    onEdit: () -> Unit
) {
    val strings = LocalStrings.current
    val category = ProductCategory.fromKey(product.category)
    val primaryName = if (language == AppLanguage.NE && product.nameNe.isNotBlank()) {
        product.nameNe
    } else {
        product.nameEn
    }
    val secondaryName = if (language == AppLanguage.NE) product.nameEn else product.nameNe
    val isOut = product.stockCount <= 0
    val isLow = product.stockCount in 1..5

    RetailCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CategoryIconBadge(category = category, size = 48.dp, iconSize = 24.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = primaryName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (secondaryName.isNotBlank() && secondaryName != primaryName) {
                    Text(
                        text = secondaryName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = formatNpr(product.sellingPrice),
                        style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleSmall.fontSize),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Surface(
                        shape = RoundedCornerShape(KiranaTokens.PillRadius),
                        color = when {
                            isOut -> MaterialTheme.colorScheme.errorContainer
                            isLow -> MaterialTheme.colorScheme.tertiaryContainer
                            else -> MaterialTheme.colorScheme.primaryContainer
                        }
                    ) {
                        Text(
                            text = "${product.stockCount} ${product.unitLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isOut -> MaterialTheme.colorScheme.error
                                isLow -> MaterialTheme.colorScheme.tertiary
                                else -> MaterialTheme.colorScheme.primary
                            },
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = onRefill,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(KiranaTokens.PillRadius),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("refill_item_${product.id}")
                ) {
                    Icon(Icons.Rounded.AddBox, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.refillBtn, style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(
                    onClick = onEdit,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(KiranaTokens.PillRadius),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("edit_item_${product.id}")
                ) {
                    Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.editBtn, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun SmartRefillSheetContent(
    product: ProductEntity,
    language: AppLanguage,
    onConfirmRefill: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalStrings.current
    var addQtyText by remember { mutableStateOf("10") }
    val delta = addQtyText.toIntOrNull() ?: 0
    val projectedTotal = (product.stockCount + delta).coerceAtLeast(0)
    val itemName = if (language == AppLanguage.NE && product.nameNe.isNotBlank()) {
        product.nameNe
    } else {
        product.nameEn
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        Text(text = strings.refillTitle, style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = itemName,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RetailCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(strings.currentStockLabel, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = "${product.stockCount} ${product.unitLabel}",
                        style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize)
                    )
                }
            }
            RetailCard(
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = strings.newStockPreview,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "$projectedTotal ${product.unitLabel}",
                        style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleLarge.fontSize),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(1, 5, 10, 25).forEach { step ->
                val pillShape = RoundedCornerShape(KiranaTokens.PillRadius)
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(pillShape)
                        .clickable {
                            val current = addQtyText.toIntOrNull() ?: 0
                            addQtyText = (current + step).toString()
                        }
                        .testTag("refill_plus_$step"),
                    shape = pillShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "+$step",
                            style = NumericDisplayStyle.copy(fontSize = MaterialTheme.typography.titleMedium.fontSize),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = addQtyText,
            onValueChange = { addQtyText = it.filter { ch -> ch.isDigit() } },
            label = { Text(strings.addQuantityLabel) },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("refill_direct_input")
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) {
                Text(strings.cancelBtn)
            }
            Button(
                onClick = { onConfirmRefill(delta) },
                enabled = delta > 0,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(2f)
                    .height(50.dp)
                    .testTag("confirm_refill_button")
            ) {
                Text("${strings.confirmRefillBtn} (+$delta)")
            }
        }
    }
}

@Composable
private fun ProductEditorSheetContent(
    existing: ProductEntity?,
    language: AppLanguage,
    onSave: (String, String, ProductCategory, Double, Double, Int, String) -> Unit,
    onDelete: (() -> Unit)?,
    onCancel: () -> Unit
) {
    val strings = LocalStrings.current
    var nameEn by remember(existing) { mutableStateOf(existing?.nameEn.orEmpty()) }
    var nameNe by remember(existing) { mutableStateOf(existing?.nameNe.orEmpty()) }
    var sellingPrice by remember(existing) {
        mutableStateOf(existing?.let { formatNumberPlain(it.sellingPrice) }.orEmpty())
    }
    var costPrice by remember(existing) {
        mutableStateOf(existing?.let { formatNumberPlain(it.costPrice) }.orEmpty())
    }
    var stockCount by remember(existing) {
        mutableStateOf(existing?.stockCount?.toString() ?: "20")
    }
    var unitLabel by remember(existing) { mutableStateOf(existing?.unitLabel ?: "pcs") }
    var selectedCategory by remember(existing) {
        mutableStateOf(ProductCategory.fromKey(existing?.category))
    }

    val isValid = nameEn.isNotBlank() && (sellingPrice.toDoubleOrNull() ?: -1.0) >= 0.0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (existing == null) strings.addItemBtn else strings.editBtn,
                style = MaterialTheme.typography.headlineSmall
            )
            if (onDelete != null) {
                TextButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_item_button")
                ) {
                    Icon(
                        Icons.Rounded.DeleteOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.deleteBtn, color = MaterialTheme.colorScheme.error)
                }
            }
        }

        OutlinedTextField(
            value = nameEn,
            onValueChange = { nameEn = it },
            label = { Text(strings.itemNameEnLabel) },
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("editor_name_en")
        )

        OutlinedTextField(
            value = nameNe,
            onValueChange = { nameNe = it },
            label = { Text(strings.itemNameNeLabel) },
            singleLine = true,
            shape = RoundedCornerShape(KiranaTokens.InputRadius),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = sellingPrice,
                onValueChange = { sellingPrice = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text(strings.sellingRateLabel) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = RoundedCornerShape(KiranaTokens.InputRadius),
                modifier = Modifier
                    .weight(1f)
                    .testTag("editor_selling_price")
            )
            OutlinedTextField(
                value = costPrice,
                onValueChange = { costPrice = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text(strings.costPriceLabel) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = RoundedCornerShape(KiranaTokens.InputRadius),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = stockCount,
                onValueChange = { stockCount = it.filter { c -> c.isDigit() } },
                label = { Text(strings.stockCountLabel) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(KiranaTokens.InputRadius),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = unitLabel,
                onValueChange = { unitLabel = it },
                label = { Text(strings.unitLabel) },
                singleLine = true,
                shape = RoundedCornerShape(KiranaTokens.InputRadius),
                modifier = Modifier.weight(1f)
            )
        }

        Text(
            text = strings.categoryLabel,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(top = 4.dp)
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ProductCategory.entries) { cat ->
                val isSelected = selectedCategory == cat
                KiranaPillChip(
                    label = cat.label(language),
                    selected = isSelected,
                    leadingIcon = cat.icon,
                    leadingIconTint = cat.contentColor,
                    onClick = { selectedCategory = cat }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) {
                Text(strings.cancelBtn)
            }
            Button(
                onClick = {
                    val sell = sellingPrice.toDoubleOrNull() ?: 0.0
                    val cost = costPrice.toDoubleOrNull() ?: (sell * 0.85)
                    val stock = stockCount.toIntOrNull() ?: 0
                    onSave(nameEn, nameNe, selectedCategory, sell, cost, stock, unitLabel)
                },
                enabled = isValid,
                shape = RoundedCornerShape(KiranaTokens.PillRadius),
                modifier = Modifier
                    .weight(2f)
                    .height(50.dp)
                    .testTag("save_inventory_item_button")
            ) {
                Text(strings.saveItemBtn)
            }
        }
    }
}
