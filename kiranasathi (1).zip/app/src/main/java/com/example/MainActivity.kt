package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.i18n.AppLanguage
import com.example.i18n.EnglishStrings
import com.example.i18n.LocalStrings
import com.example.i18n.NepaliStrings
import com.example.ui.AuthGateState
import com.example.ui.KiranaUiState
import com.example.ui.KiranaViewModel
import com.example.ui.components.FullScreenQrDialog
import com.example.ui.components.LanguageTogglePill
import com.example.ui.screens.CounterPosScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.MoreSettingsScreen
import com.example.ui.screens.PinGateScreen
import com.example.ui.screens.UdharKhataScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.KiranaSathiTheme
import java.io.File

private enum class KiranaTab(
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    COUNTER(Icons.Rounded.PointOfSale, Icons.Outlined.PointOfSale, "nav_counter"),
    INVENTORY(Icons.Rounded.Inventory2, Icons.Outlined.Inventory2, "nav_inventory"),
    UDHAR(Icons.Rounded.MenuBook, Icons.Outlined.MenuBook, "nav_udhar"),
    WALLET(Icons.Rounded.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet, "nav_wallet"),
    MORE(Icons.Rounded.Tune, Icons.Outlined.Tune, "nav_more")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KiranaSathiTheme {
                KiranaSathiRoot()
            }
        }
    }
}

@Composable
fun KiranaSathiRoot(
    viewModel: KiranaViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val strings = if (uiState.preferences.language == AppLanguage.NE) {
        NepaliStrings
    } else {
        EnglishStrings
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        viewModel.toastMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    CompositionLocalProvider(LocalStrings provides strings) {
        when (uiState.authState) {
            AuthGateState.LOADING -> {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            AuthGateState.NEEDS_SETUP, AuthGateState.LOCKED -> {
                PinGateScreen(
                    isSetupMode = uiState.authState == AuthGateState.NEEDS_SETUP,
                    initialShopName = uiState.preferences.shopName,
                    language = uiState.preferences.language,
                    onToggleLanguage = viewModel::toggleLanguage,
                    onSetupComplete = viewModel::setupMasterPin,
                    onUnlockAttempt = viewModel::unlockWithPin
                )
            }

            AuthGateState.UNLOCKED -> {
                KiranaMainShell(
                    uiState = uiState,
                    viewModel = viewModel,
                    snackbarHostState = snackbarHostState
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KiranaMainShell(
    uiState: KiranaUiState,
    viewModel: KiranaViewModel,
    snackbarHostState: SnackbarHostState
) {
    val strings = LocalStrings.current
    val context = LocalContext.current
    var currentTab by rememberSaveable { mutableStateOf(KiranaTab.COUNTER) }
    var showQuickQrDialog by remember { mutableStateOf(false) }

    // Return to Counter POS on hardware Back from secondary tabs
    BackHandler(enabled = currentTab != KiranaTab.COUNTER) {
        currentTab = KiranaTab.COUNTER
    }

    fun tabLabel(tab: KiranaTab): String = when (tab) {
        KiranaTab.COUNTER -> strings.tabCounter
        KiranaTab.INVENTORY -> strings.tabInventory
        KiranaTab.UDHAR -> strings.tabUdhar
        KiranaTab.WALLET -> strings.tabWallet
        KiranaTab.MORE -> strings.tabMore
    }

    val hasQrFile = uiState.preferences.qrImagePath.isNotBlank() &&
        File(uiState.preferences.qrImagePath).exists()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 820.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                Column {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.Storefront,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = uiState.preferences.shopName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = strings.appName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        },
                        actions = {
                            if (hasQrFile) {
                                IconButton(
                                    onClick = { showQuickQrDialog = true },
                                    modifier = Modifier.testTag("topbar_qr_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.QrCode2,
                                        contentDescription = strings.showFullQrBtn,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            LanguageTogglePill(
                                language = uiState.preferences.language,
                                onToggle = viewModel::toggleLanguage,
                                modifier = Modifier.padding(end = 10.dp)
                            )
                        }
                    )
                    androidx.compose.material3.HorizontalDivider(
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                }
            },
            bottomBar = {
                if (!useNavRail) {
                    Column {
                        androidx.compose.material3.HorizontalDivider(
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 0.dp
                        ) {
                            KiranaTab.entries.forEach { tab ->
                                val selected = currentTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tabLabel(tab)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tabLabel(tab),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.weight(0.2f))
                        KiranaTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tabLabel(tab)
                                    )
                                },
                                label = { Text(tabLabel(tab)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        KiranaTab.COUNTER -> CounterPosScreen(
                            uiState = uiState,
                            onAddToCart = viewModel::addToCart,
                            onDecrementCart = viewModel::decrementCart,
                            onClearCart = viewModel::clearCart,
                            onCompleteCheckout = viewModel::completeCheckout,
                            onQuickAddCustomer = { name, phone, onCreated ->
                                viewModel.addCustomer(name, phone, 0.0, "", onCreated)
                            }
                        )

                        KiranaTab.INVENTORY -> InventoryScreen(
                            uiState = uiState,
                            onSaveProduct = viewModel::saveProduct,
                            onDeleteProduct = viewModel::deleteProduct,
                            onRefillStock = viewModel::refillStock
                        )

                        KiranaTab.UDHAR -> UdharKhataScreen(
                            uiState = uiState,
                            onAddCustomer = { name, phone, initial, note ->
                                viewModel.addCustomer(name, phone, initial, note)
                            },
                            onAddManualUdhar = viewModel::addManualUdhar,
                            onReceivePayment = viewModel::receiveUdharPayment,
                            onSendWhatsApp = { customer ->
                                viewModel.sendWhatsAppReminder(context, customer)
                            },
                            onMarkReminderSent = viewModel::markReminderSent,
                            onSetReminderCadence = viewModel::setReminderCadence,
                            onBuildSummaryLog = viewModel::buildReminderSummaryText,
                            onNotify = viewModel::emitMessage
                        )

                        KiranaTab.WALLET -> WalletScreen(
                            uiState = uiState,
                            onAddCashAdjustment = viewModel::addCashAdjustment
                        )

                        KiranaTab.MORE -> MoreSettingsScreen(
                            uiState = uiState,
                            onToggleLanguage = viewModel::toggleLanguage,
                            onUploadQrUri = viewModel::saveQrFromUri,
                            onRemoveQr = viewModel::removeQr,
                            onExportBackup = viewModel::exportBackupToUri,
                            onImportBackup = viewModel::importBackupFromUri,
                            onUpdateShopName = viewModel::updateShopName,
                            onChangePin = viewModel::changeMasterPin,
                            onLockApp = viewModel::lockApp
                        )
                    }
                }
            }
        }
    }

    if (showQuickQrDialog) {
        FullScreenQrDialog(
            shopName = uiState.preferences.shopName,
            qrImagePath = uiState.preferences.qrImagePath,
            onDismiss = { showQuickQrDialog = false }
        )
    }
}
