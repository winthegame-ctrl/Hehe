package com.example.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BakeryDining
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Cookie
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.LocalDrink
import androidx.compose.material.icons.rounded.LocalMall
import androidx.compose.material.icons.rounded.LunchDining
import androidx.compose.material.icons.rounded.Opacity
import androidx.compose.material.icons.rounded.RamenDining
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.i18n.AppLanguage

enum class ProductCategory(
    val labelEn: String,
    val labelNe: String,
    val icon: ImageVector,
    val containerColor: Color,
    val contentColor: Color
) {
    GRAINS(
        labelEn = "Rice & Dal",
        labelNe = "चामल र दाल",
        icon = Icons.Rounded.Grain,
        containerColor = Color(0xFFFEF3C7),
        contentColor = Color(0xFFB45309)
    ),
    OIL(
        labelEn = "Cooking Oil",
        labelNe = "तेल र घ्यू",
        icon = Icons.Rounded.Opacity,
        containerColor = Color(0xFFFFEDD5),
        contentColor = Color(0xFFC2410C)
    ),
    NOODLES(
        labelEn = "Noodles",
        labelNe = "चाउचाउ",
        icon = Icons.Rounded.RamenDining,
        containerColor = Color(0xFFFEE2E2),
        contentColor = Color(0xFFB91C1C)
    ),
    BISCUITS(
        labelEn = "Biscuits",
        labelNe = "बिस्कुट",
        icon = Icons.Rounded.Cookie,
        containerColor = Color(0xFFFCE7F3),
        contentColor = Color(0xFFBE185D)
    ),
    DAIRY(
        labelEn = "Milk & Dairy",
        labelNe = "दूध र दही",
        icon = Icons.Rounded.LocalDrink,
        containerColor = Color(0xFFDBEAFE),
        contentColor = Color(0xFF1D4ED8)
    ),
    SPICES(
        labelEn = "Spices & Salt",
        labelNe = "मसला र नुन",
        icon = Icons.Rounded.Spa,
        containerColor = Color(0xFFECFCCB),
        contentColor = Color(0xFF4D7C0F)
    ),
    BEVERAGES(
        labelEn = "Tea & Drinks",
        labelNe = "चिया र पेय",
        icon = Icons.Rounded.LocalCafe,
        containerColor = Color(0xFFD6F2F0),
        contentColor = Color(0xFF0D7377)
    ),
    SNACKS(
        labelEn = "Snacks",
        labelNe = "खाजा",
        icon = Icons.Rounded.LunchDining,
        containerColor = Color(0xFFF3E8FF),
        contentColor = Color(0xFF7E22CE)
    ),
    HOUSEHOLD(
        labelEn = "Soap & Home",
        labelNe = "साबुन र घर",
        icon = Icons.Rounded.CleaningServices,
        containerColor = Color(0xFFDCFCE7),
        contentColor = Color(0xFF15803D)
    ),
    OTHER(
        labelEn = "General",
        labelNe = "अन्य",
        icon = Icons.Rounded.LocalMall,
        containerColor = Color(0xFFE2E8F0),
        contentColor = Color(0xFF334155)
    );

    fun label(language: AppLanguage): String = if (language == AppLanguage.NE) labelNe else labelEn

    companion object {
        fun fromKey(key: String?): ProductCategory =
            entries.firstOrNull { it.name.equals(key, ignoreCase = true) } ?: OTHER
    }
}
