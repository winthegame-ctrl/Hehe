package com.example.data

import org.json.JSONArray
import org.json.JSONObject

object BackupManager {

    private const val BACKUP_VERSION = 1

    fun toJsonString(snapshot: StoreBackupSnapshot): String {
        val root = JSONObject()
        root.put("version", BACKUP_VERSION)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("shopName", snapshot.shopName)
        root.put("languageCode", snapshot.languageCode)

        val productsArr = JSONArray()
        snapshot.products.forEach { p ->
            productsArr.put(JSONObject().apply {
                put("id", p.id)
                put("nameEn", p.nameEn)
                put("nameNe", p.nameNe)
                put("category", p.category)
                put("sellingPrice", p.sellingPrice)
                put("costPrice", p.costPrice)
                put("stockCount", p.stockCount)
                put("unitLabel", p.unitLabel)
                put("updatedAt", p.updatedAt)
            })
        }
        root.put("products", productsArr)

        val customersArr = JSONArray()
        snapshot.customers.forEach { c ->
            customersArr.put(JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("phone", c.phone)
                put("pendingBalance", c.pendingBalance)
                put("lastRemindedAt", c.lastRemindedAt ?: JSONObject.NULL)
                put("createdAt", c.createdAt)
            })
        }
        root.put("customers", customersArr)

        val salesArr = JSONArray()
        snapshot.sales.forEach { s ->
            salesArr.put(JSONObject().apply {
                put("id", s.id)
                put("paymentMode", s.paymentMode)
                put("customerId", s.customerId ?: JSONObject.NULL)
                put("customerNameSnapshot", s.customerNameSnapshot ?: JSONObject.NULL)
                put("totalAmount", s.totalAmount)
                put("estimatedProfit", s.estimatedProfit)
                put("cashReceived", s.cashReceived)
                put("changeGiven", s.changeGiven)
                put("itemCount", s.itemCount)
                put("summaryText", s.summaryText)
                put("timestamp", s.timestamp)
            })
        }
        root.put("sales", salesArr)

        val saleItemsArr = JSONArray()
        snapshot.saleItems.forEach { si ->
            saleItemsArr.put(JSONObject().apply {
                put("id", si.id)
                put("saleId", si.saleId)
                put("productId", si.productId)
                put("productNameSnapshot", si.productNameSnapshot)
                put("quantity", si.quantity)
                put("unitPrice", si.unitPrice)
                put("unitCost", si.unitCost)
            })
        }
        root.put("saleItems", saleItemsArr)

        val udharArr = JSONArray()
        snapshot.udharTransactions.forEach { u ->
            udharArr.put(JSONObject().apply {
                put("id", u.id)
                put("customerId", u.customerId)
                put("entryType", u.entryType)
                put("amount", u.amount)
                put("note", u.note)
                put("timestamp", u.timestamp)
            })
        }
        root.put("udharTransactions", udharArr)

        val cashArr = JSONArray()
        snapshot.cashAdjustments.forEach { ca ->
            cashArr.put(JSONObject().apply {
                put("id", ca.id)
                put("type", ca.type)
                put("amount", ca.amount)
                put("note", ca.note)
                put("timestamp", ca.timestamp)
            })
        }
        root.put("cashAdjustments", cashArr)

        val remindersArr = JSONArray()
        snapshot.reminderLogs.forEach { r ->
            remindersArr.put(JSONObject().apply {
                put("id", r.id)
                put("customerId", r.customerId)
                put("customerName", r.customerName)
                put("amount", r.amount)
                put("channel", r.channel)
                put("timestamp", r.timestamp)
            })
        }
        root.put("reminderLogs", remindersArr)

        return root.toString(2)
    }

    fun fromJsonString(jsonText: String): StoreBackupSnapshot {
        val root = JSONObject(jsonText)
        val shopName = root.optString("shopName", "Mero Kirana Pasal")
        val languageCode = root.optString("languageCode", "EN")

        val products = mutableListOf<ProductEntity>()
        val productsArr = root.optJSONArray("products") ?: JSONArray()
        for (i in 0 until productsArr.length()) {
            val o = productsArr.getJSONObject(i)
            products += ProductEntity(
                id = o.optLong("id", 0),
                nameEn = o.getString("nameEn"),
                nameNe = o.optString("nameNe", ""),
                category = o.optString("category", ProductCategory.OTHER.name),
                sellingPrice = o.getDouble("sellingPrice"),
                costPrice = o.optDouble("costPrice", 0.0),
                stockCount = o.optInt("stockCount", 0),
                unitLabel = o.optString("unitLabel", "pcs"),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }

        val customers = mutableListOf<CustomerEntity>()
        val customersArr = root.optJSONArray("customers") ?: JSONArray()
        for (i in 0 until customersArr.length()) {
            val o = customersArr.getJSONObject(i)
            customers += CustomerEntity(
                id = o.optLong("id", 0),
                name = o.getString("name"),
                phone = o.optString("phone", ""),
                pendingBalance = o.optDouble("pendingBalance", 0.0),
                lastRemindedAt = if (o.isNull("lastRemindedAt")) null else o.optLong("lastRemindedAt"),
                createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )
        }

        val sales = mutableListOf<SaleEntity>()
        val salesArr = root.optJSONArray("sales") ?: JSONArray()
        for (i in 0 until salesArr.length()) {
            val o = salesArr.getJSONObject(i)
            sales += SaleEntity(
                id = o.optLong("id", 0),
                paymentMode = o.optString("paymentMode", PaymentMode.CASH.name),
                customerId = if (o.isNull("customerId")) null else o.optLong("customerId"),
                customerNameSnapshot = if (o.isNull("customerNameSnapshot")) null else o.optString("customerNameSnapshot"),
                totalAmount = o.optDouble("totalAmount", 0.0),
                estimatedProfit = o.optDouble("estimatedProfit", 0.0),
                cashReceived = o.optDouble("cashReceived", 0.0),
                changeGiven = o.optDouble("changeGiven", 0.0),
                itemCount = o.optInt("itemCount", 0),
                summaryText = o.optString("summaryText", ""),
                timestamp = o.optLong("timestamp", System.currentTimeMillis())
            )
        }

        val saleItems = mutableListOf<SaleItemEntity>()
        val saleItemsArr = root.optJSONArray("saleItems") ?: JSONArray()
        for (i in 0 until saleItemsArr.length()) {
            val o = saleItemsArr.getJSONObject(i)
            saleItems += SaleItemEntity(
                id = o.optLong("id", 0),
                saleId = o.optLong("saleId", 0),
                productId = o.optLong("productId", 0),
                productNameSnapshot = o.optString("productNameSnapshot", ""),
                quantity = o.optInt("quantity", 1),
                unitPrice = o.optDouble("unitPrice", 0.0),
                unitCost = o.optDouble("unitCost", 0.0)
            )
        }

        val udharList = mutableListOf<UdharTransactionEntity>()
        val udharArr = root.optJSONArray("udharTransactions") ?: JSONArray()
        for (i in 0 until udharArr.length()) {
            val o = udharArr.getJSONObject(i)
            udharList += UdharTransactionEntity(
                id = o.optLong("id", 0),
                customerId = o.optLong("customerId", 0),
                entryType = o.optString("entryType", UdharEntryType.CREDIT_ADDED.name),
                amount = o.optDouble("amount", 0.0),
                note = o.optString("note", ""),
                timestamp = o.optLong("timestamp", System.currentTimeMillis())
            )
        }

        val cashList = mutableListOf<CashAdjustmentEntity>()
        val cashArr = root.optJSONArray("cashAdjustments") ?: JSONArray()
        for (i in 0 until cashArr.length()) {
            val o = cashArr.getJSONObject(i)
            cashList += CashAdjustmentEntity(
                id = o.optLong("id", 0),
                type = o.optString("type", CashAdjustmentType.CASH_IN.name),
                amount = o.optDouble("amount", 0.0),
                note = o.optString("note", ""),
                timestamp = o.optLong("timestamp", System.currentTimeMillis())
            )
        }

        val reminderList = mutableListOf<ReminderLogEntity>()
        val remindersArr = root.optJSONArray("reminderLogs") ?: JSONArray()
        for (i in 0 until remindersArr.length()) {
            val o = remindersArr.getJSONObject(i)
            reminderList += ReminderLogEntity(
                id = o.optLong("id", 0),
                customerId = o.optLong("customerId", 0),
                customerName = o.optString("customerName", ""),
                amount = o.optDouble("amount", 0.0),
                channel = o.optString("channel", "WHATSAPP"),
                timestamp = o.optLong("timestamp", System.currentTimeMillis())
            )
        }

        return StoreBackupSnapshot(
            shopName = shopName,
            languageCode = languageCode,
            products = products,
            customers = customers,
            sales = sales,
            saleItems = saleItems,
            udharTransactions = udharList,
            cashAdjustments = cashList,
            reminderLogs = reminderList
        )
    }

    fun toCsvString(snapshot: StoreBackupSnapshot): String {
        val sb = StringBuilder()
        sb.appendLine("META,shopName,${csvEscape(snapshot.shopName)},languageCode,${csvEscape(snapshot.languageCode)}")
        sb.appendLine("SECTION,PRODUCTS")
        sb.appendLine("id,nameEn,nameNe,category,sellingPrice,costPrice,stockCount,unitLabel,updatedAt")
        snapshot.products.forEach { p ->
            sb.appendLine(
                listOf(
                    p.id.toString(),
                    csvEscape(p.nameEn),
                    csvEscape(p.nameNe),
                    csvEscape(p.category),
                    p.sellingPrice.toString(),
                    p.costPrice.toString(),
                    p.stockCount.toString(),
                    csvEscape(p.unitLabel),
                    p.updatedAt.toString()
                ).joinToString(",")
            )
        }

        sb.appendLine("SECTION,CUSTOMERS")
        sb.appendLine("id,name,phone,pendingBalance,lastRemindedAt,createdAt")
        snapshot.customers.forEach { c ->
            sb.appendLine(
                listOf(
                    c.id.toString(),
                    csvEscape(c.name),
                    csvEscape(c.phone),
                    c.pendingBalance.toString(),
                    (c.lastRemindedAt?.toString() ?: ""),
                    c.createdAt.toString()
                ).joinToString(",")
            )
        }

        sb.appendLine("SECTION,SALES")
        sb.appendLine("id,paymentMode,customerId,customerNameSnapshot,totalAmount,estimatedProfit,cashReceived,changeGiven,itemCount,summaryText,timestamp")
        snapshot.sales.forEach { s ->
            sb.appendLine(
                listOf(
                    s.id.toString(),
                    csvEscape(s.paymentMode),
                    (s.customerId?.toString() ?: ""),
                    csvEscape(s.customerNameSnapshot.orEmpty()),
                    s.totalAmount.toString(),
                    s.estimatedProfit.toString(),
                    s.cashReceived.toString(),
                    s.changeGiven.toString(),
                    s.itemCount.toString(),
                    csvEscape(s.summaryText),
                    s.timestamp.toString()
                ).joinToString(",")
            )
        }

        sb.appendLine("SECTION,UDHAR_TRANSACTIONS")
        sb.appendLine("id,customerId,entryType,amount,note,timestamp")
        snapshot.udharTransactions.forEach { u ->
            sb.appendLine(
                listOf(
                    u.id.toString(),
                    u.customerId.toString(),
                    csvEscape(u.entryType),
                    u.amount.toString(),
                    csvEscape(u.note),
                    u.timestamp.toString()
                ).joinToString(",")
            )
        }

        sb.appendLine("SECTION,CASH_ADJUSTMENTS")
        sb.appendLine("id,type,amount,note,timestamp")
        snapshot.cashAdjustments.forEach { ca ->
            sb.appendLine(
                listOf(
                    ca.id.toString(),
                    csvEscape(ca.type),
                    ca.amount.toString(),
                    csvEscape(ca.note),
                    ca.timestamp.toString()
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun fromCsvString(csvText: String): StoreBackupSnapshot {
        val lines = csvText.lines().filter { it.isNotBlank() }
        var shopName = "Mero Kirana Pasal"
        var languageCode = "EN"
        var currentSection = ""
        var expectHeader = false

        val products = mutableListOf<ProductEntity>()
        val customers = mutableListOf<CustomerEntity>()
        val sales = mutableListOf<SaleEntity>()
        val udharList = mutableListOf<UdharTransactionEntity>()
        val cashList = mutableListOf<CashAdjustmentEntity>()

        for (line in lines) {
            val cols = parseCsvRow(line)
            if (cols.isEmpty()) continue
            if (cols[0] == "META" && cols.size >= 5) {
                shopName = cols[2]
                languageCode = cols[4]
                continue
            }
            if (cols[0] == "SECTION" && cols.size >= 2) {
                currentSection = cols[1]
                expectHeader = true
                continue
            }
            if (expectHeader) {
                expectHeader = false
                continue
            }
            when (currentSection) {
                "PRODUCTS" -> if (cols.size >= 9) {
                    products += ProductEntity(
                        id = cols[0].toLongOrNull() ?: 0L,
                        nameEn = cols[1],
                        nameNe = cols[2],
                        category = cols[3],
                        sellingPrice = cols[4].toDoubleOrNull() ?: 0.0,
                        costPrice = cols[5].toDoubleOrNull() ?: 0.0,
                        stockCount = cols[6].toIntOrNull() ?: 0,
                        unitLabel = cols[7],
                        updatedAt = cols[8].toLongOrNull() ?: System.currentTimeMillis()
                    )
                }
                "CUSTOMERS" -> if (cols.size >= 6) {
                    customers += CustomerEntity(
                        id = cols[0].toLongOrNull() ?: 0L,
                        name = cols[1],
                        phone = cols[2],
                        pendingBalance = cols[3].toDoubleOrNull() ?: 0.0,
                        lastRemindedAt = cols[4].toLongOrNull(),
                        createdAt = cols[5].toLongOrNull() ?: System.currentTimeMillis()
                    )
                }
                "SALES" -> if (cols.size >= 11) {
                    sales += SaleEntity(
                        id = cols[0].toLongOrNull() ?: 0L,
                        paymentMode = cols[1],
                        customerId = cols[2].toLongOrNull(),
                        customerNameSnapshot = cols[3].ifBlank { null },
                        totalAmount = cols[4].toDoubleOrNull() ?: 0.0,
                        estimatedProfit = cols[5].toDoubleOrNull() ?: 0.0,
                        cashReceived = cols[6].toDoubleOrNull() ?: 0.0,
                        changeGiven = cols[7].toDoubleOrNull() ?: 0.0,
                        itemCount = cols[8].toIntOrNull() ?: 0,
                        summaryText = cols[9],
                        timestamp = cols[10].toLongOrNull() ?: System.currentTimeMillis()
                    )
                }
                "UDHAR_TRANSACTIONS" -> if (cols.size >= 6) {
                    udharList += UdharTransactionEntity(
                        id = cols[0].toLongOrNull() ?: 0L,
                        customerId = cols[1].toLongOrNull() ?: 0L,
                        entryType = cols[2],
                        amount = cols[3].toDoubleOrNull() ?: 0.0,
                        note = cols[4],
                        timestamp = cols[5].toLongOrNull() ?: System.currentTimeMillis()
                    )
                }
                "CASH_ADJUSTMENTS" -> if (cols.size >= 5) {
                    cashList += CashAdjustmentEntity(
                        id = cols[0].toLongOrNull() ?: 0L,
                        type = cols[1],
                        amount = cols[2].toDoubleOrNull() ?: 0.0,
                        note = cols[3],
                        timestamp = cols[4].toLongOrNull() ?: System.currentTimeMillis()
                    )
                }
            }
        }

        require(products.isNotEmpty() || customers.isNotEmpty() || sales.isNotEmpty()) {
            "Empty or unrecognized CSV backup file"
        }

        return StoreBackupSnapshot(
            shopName = shopName,
            languageCode = languageCode,
            products = products,
            customers = customers,
            sales = sales,
            saleItems = emptyList(),
            udharTransactions = udharList,
            cashAdjustments = cashList,
            reminderLogs = emptyList()
        )
    }

    fun parseBackupContent(rawText: String): StoreBackupSnapshot {
        val trimmed = rawText.trimStart()
        return if (trimmed.startsWith("{")) {
            fromJsonString(trimmed)
        } else {
            fromCsvString(trimmed)
        }
    }

    private fun csvEscape(value: String): String {
        val needsQuotes = value.contains(",") || value.contains("\"") || value.contains("\n")
        return if (needsQuotes) {
            "\"${value.replace("\"", "\"\"")}\""
        } else {
            value
        }
    }

    private fun parseCsvRow(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < line.length && line[i + 1] == '"') {
                        current.append('"')
                        i++
                    } else {
                        inQuotes = false
                    }
                } else {
                    current.append(c)
                }
            } else {
                when (c) {
                    '"' -> inQuotes = true
                    ',' -> {
                        result += current.toString()
                        current.clear()
                    }
                    else -> current.append(c)
                }
            }
            i++
        }
        result += current.toString()
        return result
    }
}
