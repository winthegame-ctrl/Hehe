package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface KiranaDao {

    @Query("SELECT * FROM products ORDER BY nameEn ASC")
    fun observeProducts(): Flow<List<ProductEntity>>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun getProductCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteProductById(id: Long)

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: Long): ProductEntity?

    @Query("UPDATE products SET stockCount = MAX(0, stockCount - :delta), updatedAt = :timestamp WHERE id = :productId")
    suspend fun deductProductStock(productId: Long, delta: Int, timestamp: Long)

    @Query("UPDATE products SET stockCount = MAX(0, stockCount + :delta), updatedAt = :timestamp WHERE id = :productId")
    suspend fun addProductStock(productId: Long, delta: Int, timestamp: Long)

    // Customers
    @Query("SELECT * FROM customers ORDER BY pendingBalance DESC, name ASC")
    fun observeCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: Long): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<CustomerEntity>)

    @Query("UPDATE customers SET pendingBalance = MAX(0.0, pendingBalance + :delta) WHERE id = :customerId")
    suspend fun adjustCustomerBalance(customerId: Long, delta: Double)

    @Query("UPDATE customers SET lastRemindedAt = :timestamp WHERE id = :customerId")
    suspend fun updateCustomerLastReminded(customerId: Long, timestamp: Long)

    // Sales & SaleItems
    @Query("SELECT * FROM sales ORDER BY timestamp DESC")
    fun observeSales(): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sale_items ORDER BY id DESC")
    fun observeSaleItems(): Flow<List<SaleItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: SaleEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSales(sales: List<SaleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaleItems(items: List<SaleItemEntity>)

    // Udhar Transactions
    @Query("SELECT * FROM udhar_transactions ORDER BY timestamp DESC")
    fun observeUdharTransactions(): Flow<List<UdharTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUdharTransaction(entry: UdharTransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUdharTransactions(entries: List<UdharTransactionEntity>)

    // Cash Adjustments
    @Query("SELECT * FROM cash_adjustments ORDER BY timestamp DESC")
    fun observeCashAdjustments(): Flow<List<CashAdjustmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashAdjustment(entry: CashAdjustmentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashAdjustments(entries: List<CashAdjustmentEntity>)

    // Reminder Logs
    @Query("SELECT * FROM reminder_logs ORDER BY timestamp DESC")
    fun observeReminderLogs(): Flow<List<ReminderLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminderLog(log: ReminderLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminderLogs(logs: List<ReminderLogEntity>)

    // Atomic Checkout Transaction
    @Transaction
    suspend fun completeCheckoutTransaction(
        sale: SaleEntity,
        cartLines: List<Pair<ProductEntity, Int>>,
        udharNote: String
    ): Long {
        val now = sale.timestamp
        val saleId = insertSale(sale)
        val lineEntities = cartLines.map { (product, qty) ->
            deductProductStock(product.id, qty, now)
            SaleItemEntity(
                saleId = saleId,
                productId = product.id,
                productNameSnapshot = product.nameEn,
                quantity = qty,
                unitPrice = product.sellingPrice,
                unitCost = product.costPrice
            )
        }
        insertSaleItems(lineEntities)

        if (sale.paymentMode == PaymentMode.UDHAR.name && sale.customerId != null) {
            adjustCustomerBalance(sale.customerId, sale.totalAmount)
            insertUdharTransaction(
                UdharTransactionEntity(
                    customerId = sale.customerId,
                    entryType = UdharEntryType.CREDIT_ADDED.name,
                    amount = sale.totalAmount,
                    note = udharNote,
                    timestamp = now
                )
            )
        }
        return saleId
    }

    @Transaction
    suspend fun addManualUdharTransaction(
        customerId: Long,
        amount: Double,
        note: String,
        timestamp: Long = System.currentTimeMillis()
    ) {
        adjustCustomerBalance(customerId, amount)
        insertUdharTransaction(
            UdharTransactionEntity(
                customerId = customerId,
                entryType = UdharEntryType.CREDIT_ADDED.name,
                amount = amount,
                note = note,
                timestamp = timestamp
            )
        )
    }

    @Transaction
    suspend fun recordUdharPaymentTransaction(
        customerId: Long,
        amount: Double,
        note: String,
        timestamp: Long = System.currentTimeMillis()
    ) {
        adjustCustomerBalance(customerId, -amount)
        insertUdharTransaction(
            UdharTransactionEntity(
                customerId = customerId,
                entryType = UdharEntryType.PAYMENT_RECEIVED.name,
                amount = amount,
                note = note,
                timestamp = timestamp
            )
        )
    }

    // Clear & Restore All Data Atomically
    @Query("DELETE FROM products")
    suspend fun clearProducts()

    @Query("DELETE FROM customers")
    suspend fun clearCustomers()

    @Query("DELETE FROM sales")
    suspend fun clearSales()

    @Query("DELETE FROM sale_items")
    suspend fun clearSaleItems()

    @Query("DELETE FROM udhar_transactions")
    suspend fun clearUdharTransactions()

    @Query("DELETE FROM cash_adjustments")
    suspend fun clearCashAdjustments()

    @Query("DELETE FROM reminder_logs")
    suspend fun clearReminderLogs()

    @Transaction
    suspend fun replaceAllDataTransaction(
        products: List<ProductEntity>,
        customers: List<CustomerEntity>,
        sales: List<SaleEntity>,
        saleItems: List<SaleItemEntity>,
        udharTransactions: List<UdharTransactionEntity>,
        cashAdjustments: List<CashAdjustmentEntity>,
        reminderLogs: List<ReminderLogEntity>
    ) {
        clearSaleItems()
        clearSales()
        clearUdharTransactions()
        clearCashAdjustments()
        clearReminderLogs()
        clearCustomers()
        clearProducts()

        if (products.isNotEmpty()) insertProducts(products)
        if (customers.isNotEmpty()) insertCustomers(customers)
        if (sales.isNotEmpty()) insertSales(sales)
        if (saleItems.isNotEmpty()) insertSaleItems(saleItems)
        if (udharTransactions.isNotEmpty()) insertUdharTransactions(udharTransactions)
        if (cashAdjustments.isNotEmpty()) insertCashAdjustments(cashAdjustments)
        if (reminderLogs.isNotEmpty()) insertReminderLogs(reminderLogs)
    }
}
