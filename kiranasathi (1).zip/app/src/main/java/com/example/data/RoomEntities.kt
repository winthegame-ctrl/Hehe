package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PaymentMode {
    CASH,
    QR,
    UDHAR
}

enum class UdharEntryType {
    CREDIT_ADDED,
    PAYMENT_RECEIVED
}

enum class CashAdjustmentType {
    CASH_IN,
    CASH_OUT
}

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nameEn: String,
    val nameNe: String,
    val category: String,
    val sellingPrice: Double,
    val costPrice: Double,
    val stockCount: Int,
    val unitLabel: String = "pcs",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val pendingBalance: Double = 0.0,
    val lastRemindedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sales")
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val paymentMode: String,
    val customerId: Long? = null,
    val customerNameSnapshot: String? = null,
    val totalAmount: Double,
    val estimatedProfit: Double,
    val cashReceived: Double = 0.0,
    val changeGiven: Double = 0.0,
    val itemCount: Int,
    val summaryText: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "sale_items")
data class SaleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productNameSnapshot: String,
    val quantity: Int,
    val unitPrice: Double,
    val unitCost: Double
)

@Entity(tableName = "udhar_transactions")
data class UdharTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val entryType: String,
    val amount: Double,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "cash_adjustments")
data class CashAdjustmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val amount: Double,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminder_logs")
data class ReminderLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val amount: Double,
    val channel: String = "WHATSAPP",
    val timestamp: Long = System.currentTimeMillis()
)
