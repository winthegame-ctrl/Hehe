package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.i18n.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "kiranasaathi_prefs")

data class ShopPreferences(
    val pinHash: String = "",
    val isLocked: Boolean = false,
    val language: AppLanguage = AppLanguage.EN,
    val shopName: String = "Mero Kirana Pasal",
    val qrImagePath: String = "",
    val reminderCadence: String = "DAILY",
    val starterSeeded: Boolean = false
)

class PreferencesStore(private val context: Context) {

    private object Keys {
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val IS_LOCKED = booleanPreferencesKey("is_locked")
        val LANGUAGE = stringPreferencesKey("language")
        val SHOP_NAME = stringPreferencesKey("shop_name")
        val QR_IMAGE_PATH = stringPreferencesKey("qr_image_path")
        val REMINDER_CADENCE = stringPreferencesKey("reminder_cadence")
        val STARTER_SEEDED = booleanPreferencesKey("starter_seeded")
    }

    val preferencesFlow: Flow<ShopPreferences> = context.dataStore.data.map { prefs ->
        ShopPreferences(
            pinHash = prefs[Keys.PIN_HASH].orEmpty(),
            isLocked = prefs[Keys.IS_LOCKED] ?: false,
            language = AppLanguage.fromCode(prefs[Keys.LANGUAGE]),
            shopName = prefs[Keys.SHOP_NAME]?.takeIf { it.isNotBlank() } ?: "Mero Kirana Pasal",
            qrImagePath = prefs[Keys.QR_IMAGE_PATH].orEmpty(),
            reminderCadence = prefs[Keys.REMINDER_CADENCE]?.takeIf { it.isNotBlank() } ?: "DAILY",
            starterSeeded = prefs[Keys.STARTER_SEEDED] ?: false
        )
    }

    suspend fun saveInitialPin(pinHash: String, shopName: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.PIN_HASH] = pinHash
            prefs[Keys.IS_LOCKED] = false
            if (shopName.isNotBlank()) {
                prefs[Keys.SHOP_NAME] = shopName.trim()
            }
        }
    }

    suspend fun updatePin(pinHash: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.PIN_HASH] = pinHash
        }
    }

    suspend fun setLocked(locked: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_LOCKED] = locked
        }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.name
        }
    }

    suspend fun setShopName(name: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SHOP_NAME] = name.trim().ifBlank { "Mero Kirana Pasal" }
        }
    }

    suspend fun setQrImagePath(path: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.QR_IMAGE_PATH] = path
        }
    }

    suspend fun setReminderCadence(cadence: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.REMINDER_CADENCE] = cadence
        }
    }

    suspend fun markStarterSeeded() {
        context.dataStore.edit { prefs ->
            prefs[Keys.STARTER_SEEDED] = true
        }
    }
}
