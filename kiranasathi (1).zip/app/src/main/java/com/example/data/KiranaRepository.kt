package com.example.data

import com.example.i18n.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class KiranaRepository(
    private val dao: KiranaDao,
    private val preferencesStore: PreferencesStore
) {
    val preferences: Flow<ShopPreferences> = preferencesStore.preferencesFlow
    val products: Flow<List<ProductEntity>> = dao.observeProducts()
    val customers: Flow<List<CustomerEntity>> = dao.observeCustomers()
    val sales: Flow<List<SaleEntity>> = dao.observeSales()
    val saleItems: Flow<List<SaleItemEntity>> = dao.observeSaleItems()
    val udharTransactions: Flow<List<UdharTransactionEntity>> = dao.observeUdharTransactions()
    val cashAdjustments: Flow<List<CashAdjustmentEntity>> = dao.observeCashAdjustments()
    val reminderLogs: Flow<List<ReminderLogEntity>> = dao.observeReminderLogs()

    suspend fun ensureStarterCatalogSeeded() {
        val prefs = preferencesStore.preferencesFlow.first()
        if (!prefs.starterSeeded && dao.getProductCount() == 0) {
            dao.insertProducts(StarterCatalogSeeder.defaultNepaliKiranaItems())
            preferencesStore.markStarterSeeded()
        } else if (!prefs.starterSeeded) {
            preferencesStore.markStarterSeeded()
        }
    }

    suspend fun saveInitialPin(pinHash: String, shopName: String) {
        preferencesStore.saveInitialPin(pinHash, shopName)
        ensureStarterCatalogSeeded()
    }

    suspend fun updatePin(pinHash: String) = preferencesStore.updatePin(pinHash)

    suspend fun setLocked(locked: Boolean) = preferencesStore.setLocked(locked)

    suspend fun setLanguage(language: AppLanguage) = preferencesStore.setLanguage(language)

    suspend fun setShopName(name: String) = preferencesStore.setShopName(name)

    suspend fun setQrImagePath(path: String) = preferencesStore.setQrImagePath(path)

    suspend fun setReminderCadence(cadence: String) = preferencesStore.setReminderCadence(cadence)

    suspend fun saveProduct(product: ProductEntity): Long {
        return if (product.id == 0L) {
            dao.insertProduct(product.copy(updatedAt = System.currentTimeMillis()))
        } else {
            val updated = product.copy(updatedAt = System.currentTimeMillis())
            dao.updateProduct(updated)
            updated.id
        }
    }

    suspend fun deleteProduct(productId: Long) = dao.deleteProductById(productId)

    suspend fun refillProductStock(productId: Long, delta: Int) {
        dao.addProductStock(productId, delta, System.currentTimeMillis())
    }

    suspend fun completeCheckout(
        sale: SaleEntity,
        cartLines: List<Pair<ProductEntity, Int>>,
        udharNote: String
    ): Long = dao.completeCheckoutTransaction(sale, cartLines, udharNote)

    suspend fun addCustomer(name: String, phone: String, initialUdhar: Double = 0.0, note: String = ""): Long {
        val now = System.currentTimeMillis()
        val id = dao.insertCustomer(
            CustomerEntity(
                name = name.trim(),
                phone = phone.trim(),
                pendingBalance = initialUdhar.coerceAtLeast(0.0),
                createdAt = now
            )
        )
        if (initialUdhar > 0.0) {
            dao.insertUdharTransaction(
                UdharTransactionEntity(
                    customerId = id,
                    entryType = UdharEntryType.CREDIT_ADDED.name,
                    amount = initialUdhar,
                    note = note.ifBlank { "Opening balance" },
                    timestamp = now
                )
            )
        }
        return id
    }

    suspend fun addManualUdhar(customerId: Long, amount: Double, note: String) {
        dao.addManualUdharTransaction(customerId, amount, note)
    }

    suspend fun receiveUdharPayment(customerId: Long, amount: Double, note: String) {
        dao.recordUdharPaymentTransaction(customerId, amount, note)
    }

    suspend fun logWhatsAppReminder(customer: CustomerEntity) {
        val now = System.currentTimeMillis()
        dao.updateCustomerLastReminded(customer.id, now)
        dao.insertReminderLog(
            ReminderLogEntity(
                customerId = customer.id,
                customerName = customer.name,
                amount = customer.pendingBalance,
                timestamp = now
            )
        )
    }

    suspend fun addCashAdjustment(type: CashAdjustmentType, amount: Double, note: String) {
        dao.insertCashAdjustment(
            CashAdjustmentEntity(
                type = type.name,
                amount = amount,
                note = note.trim()
            )
        )
    }

    suspend fun exportSnapshot(): StoreBackupSnapshot {
        val prefs = preferencesStore.preferencesFlow.first()
        return StoreBackupSnapshot(
            shopName = prefs.shopName,
            languageCode = prefs.language.name,
            products = dao.observeProducts().first(),
            customers = dao.observeCustomers().first(),
            sales = dao.observeSales().first(),
            saleItems = dao.observeSaleItems().first(),
            udharTransactions = dao.observeUdharTransactions().first(),
            cashAdjustments = dao.observeCashAdjustments().first(),
            reminderLogs = dao.observeReminderLogs().first()
        )
    }

    suspend fun restoreSnapshot(snapshot: StoreBackupSnapshot) {
        dao.replaceAllDataTransaction(
            products = snapshot.products,
            customers = snapshot.customers,
            sales = snapshot.sales,
            saleItems = snapshot.saleItems,
            udharTransactions = snapshot.udharTransactions,
            cashAdjustments = snapshot.cashAdjustments,
            reminderLogs = snapshot.reminderLogs
        )
        if (snapshot.shopName.isNotBlank()) {
            preferencesStore.setShopName(snapshot.shopName)
        }
        preferencesStore.markStarterSeeded()
    }
}

data class StoreBackupSnapshot(
    val shopName: String,
    val languageCode: String,
    val products: List<ProductEntity>,
    val customers: List<CustomerEntity>,
    val sales: List<SaleEntity>,
    val saleItems: List<SaleItemEntity>,
    val udharTransactions: List<UdharTransactionEntity>,
    val cashAdjustments: List<CashAdjustmentEntity>,
    val reminderLogs: List<ReminderLogEntity>
)
