package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProductEntity::class,
        CustomerEntity::class,
        SaleEntity::class,
        SaleItemEntity::class,
        UdharTransactionEntity::class,
        CashAdjustmentEntity::class,
        ReminderLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KiranaDatabase : RoomDatabase() {
    abstract fun kiranaDao(): KiranaDao

    companion object {
        @Volatile
        private var INSTANCE: KiranaDatabase? = null

        fun getInstance(context: Context): KiranaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    KiranaDatabase::class.java,
                    "kiranasaathi.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

object StarterCatalogSeeder {
    fun defaultNepaliKiranaItems(): List<ProductEntity> = listOf(
        ProductEntity(
            nameEn = "Sona Mansuli Rice (1kg)",
            nameNe = "सोना मन्सुली चामल (१ केजी)",
            category = ProductCategory.GRAINS.name,
            sellingPrice = 90.0,
            costPrice = 78.0,
            stockCount = 45,
            unitLabel = "kg"
        ),
        ProductEntity(
            nameEn = "Musuro Dal (1kg)",
            nameNe = "मुसुरो दाल (१ केजी)",
            category = ProductCategory.GRAINS.name,
            sellingPrice = 165.0,
            costPrice = 145.0,
            stockCount = 24,
            unitLabel = "kg"
        ),
        ProductEntity(
            nameEn = "Swastik Sunflower Oil (1L)",
            nameNe = "स्वस्तिक सनफ्लावर तेल (१ लि.)",
            category = ProductCategory.OIL.name,
            sellingPrice = 240.0,
            costPrice = 218.0,
            stockCount = 18,
            unitLabel = "ltr"
        ),
        ProductEntity(
            nameEn = "Dhara Mustard Oil (1L)",
            nameNe = "धारा तोरीको तेल (१ लि.)",
            category = ProductCategory.OIL.name,
            sellingPrice = 290.0,
            costPrice = 265.0,
            stockCount = 14,
            unitLabel = "ltr"
        ),
        ProductEntity(
            nameEn = "Wai Wai Chicken Noodles",
            nameNe = "वाइ वाइ चिकेन चाउचाउ",
            category = ProductCategory.NOODLES.name,
            sellingPrice = 20.0,
            costPrice = 17.0,
            stockCount = 60,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Current Hot & Spicy",
            nameNe = "करेन्ट पिरो चाउचाउ",
            category = ProductCategory.NOODLES.name,
            sellingPrice = 50.0,
            costPrice = 42.0,
            stockCount = 30,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Marie Gold Biscuit",
            nameNe = "मेरी गोल्ड बिस्कुट",
            category = ProductCategory.BISCUITS.name,
            sellingPrice = 30.0,
            costPrice = 25.0,
            stockCount = 36,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Oreo Cream Biscuit",
            nameNe = "ओरियो क्रिम बिस्कुट",
            category = ProductCategory.BISCUITS.name,
            sellingPrice = 40.0,
            costPrice = 34.0,
            stockCount = 22,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "DDC Fresh Milk (500ml)",
            nameNe = "डीडीसी ताजा दूध (५०० मि.लि.)",
            category = ProductCategory.DAIRY.name,
            sellingPrice = 50.0,
            costPrice = 45.0,
            stockCount = 16,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Aayo Iodized Salt (1kg)",
            nameNe = "आयो नुन (१ केजी)",
            category = ProductCategory.SPICES.name,
            sellingPrice = 28.0,
            costPrice = 23.0,
            stockCount = 40,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Everest Haldi Powder (100g)",
            nameNe = "एभरेस्ट बेसार (१०० ग्राम)",
            category = ProductCategory.SPICES.name,
            sellingPrice = 65.0,
            costPrice = 54.0,
            stockCount = 20,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Tokla Gold Tea (250g)",
            nameNe = "टोक्ला गोल्ड चिया (२५० ग्राम)",
            category = ProductCategory.BEVERAGES.name,
            sellingPrice = 160.0,
            costPrice = 140.0,
            stockCount = 15,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Coca-Cola (500ml)",
            nameNe = "कोका-कोला (५०० मि.लि.)",
            category = ProductCategory.BEVERAGES.name,
            sellingPrice = 65.0,
            costPrice = 55.0,
            stockCount = 24,
            unitLabel = "btl"
        ),
        ProductEntity(
            nameEn = "Kurkure Masala Munch",
            nameNe = "कुरकुरे मसला मन्च",
            category = ProductCategory.SNACKS.name,
            sellingPrice = 20.0,
            costPrice = 16.5,
            stockCount = 28,
            unitLabel = "pkt"
        ),
        ProductEntity(
            nameEn = "Lifebuoy Total Soap",
            nameNe = "लाइफब्वाइ साबुन",
            category = ProductCategory.HOUSEHOLD.name,
            sellingPrice = 45.0,
            costPrice = 38.0,
            stockCount = 18,
            unitLabel = "pcs"
        ),
        ProductEntity(
            nameEn = "Sugar / Chini (1kg)",
            nameNe = "चिनी (१ केजी)",
            category = ProductCategory.GRAINS.name,
            sellingPrice = 105.0,
            costPrice = 94.0,
            stockCount = 32,
            unitLabel = "kg"
        )
    )
}
