package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.CustomerEntity
import com.example.i18n.formatNumberPlain
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object SecurityUtils {
    fun hashPin(pin: String): String {
        val salted = "KiranaSathi_NP_2026::$pin"
        val digest = MessageDigest.getInstance("SHA-256").digest(salted.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}

object WhatsAppHelper {
    fun buildUdharReminderMessage(
        customerName: String,
        shopName: String,
        pendingAmount: Double
    ): String {
        val amountStr = formatNumberPlain(pendingAmount)
        return "नमस्ते $customerName ज्यू, $shopName मा तपाईँको रु. $amountStr बाँकी हिसाब रहेको छ। कृपया यथाशीघ्र भुक्तानी गरिदिनुहोला। धन्यवाद!"
    }

    fun formatNepalPhoneForWhatsApp(rawPhone: String): String {
        val digits = rawPhone.filter { it.isDigit() }
        return when {
            digits.isEmpty() -> ""
            digits.startsWith("977") -> digits
            digits.length == 10 && digits.startsWith("9") -> "977$digits"
            digits.startsWith("0") && digits.length == 11 -> "977${digits.drop(1)}"
            else -> digits
        }
    }

    fun launchWhatsAppReminder(
        context: Context,
        customer: CustomerEntity,
        shopName: String
    ) {
        val message = buildUdharReminderMessage(
            customerName = customer.name,
            shopName = shopName,
            pendingAmount = customer.pendingBalance
        )
        val waPhone = formatNepalPhoneForWhatsApp(customer.phone)
        val encoded = Uri.encode(message)
        val url = if (waPhone.isNotEmpty()) {
            "https://wa.me/$waPhone?text=$encoded"
        } else {
            "https://wa.me/?text=$encoded"
        }

        val viewIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(viewIntent)
        } catch (_: Exception) {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Send Reminder").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }
}

object QrStorageHelper {
    private const val QR_FILE_NAME = "shop_payment_qr.jpg"

    fun copyUriToInternalQrFile(context: Context, sourceUri: Uri): String? {
        return try {
            val destFile = File(context.filesDir, QR_FILE_NAME)
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            if (destFile.exists() && destFile.length() > 0L) destFile.absolutePath else null
        } catch (_: Exception) {
            null
        }
    }

    fun deleteInternalQrFile(path: String) {
        if (path.isNotBlank()) {
            runCatching { File(path).delete() }
        }
    }
}

object DateTimeHelper {
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
    private val dateTimeFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH)
    private val fileDateFormat = SimpleDateFormat("yyyyMMdd_HHmm", Locale.ENGLISH)

    fun startOfTodayMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun formatTimeOrDate(timestamp: Long): String {
        return if (timestamp >= startOfTodayMillis()) {
            timeFormat.format(Date(timestamp))
        } else {
            dateTimeFormat.format(Date(timestamp))
        }
    }

    fun backupTimestampTag(): String = fileDateFormat.format(Date())
}
