package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.BackupManager
import com.example.data.CustomerEntity
import com.example.data.ProductCategory
import com.example.data.ProductEntity
import com.example.data.SaleEntity
import com.example.data.StoreBackupSnapshot
import com.example.util.SecurityUtils
import com.example.util.WhatsAppHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read KiranaSathi app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("KiranaSathi", appName)
    }

    @Test
    fun `json and csv backup round trip preserves products and customers`() {
        val snapshot = StoreBackupSnapshot(
            shopName = "Sita Kirana Pasal",
            languageCode = "NE",
            products = listOf(
                ProductEntity(
                    id = 1,
                    nameEn = "Sona Mansuli Rice",
                    nameNe = "सोना मन्सुली चामल",
                    category = ProductCategory.GRAINS.name,
                    sellingPrice = 90.0,
                    costPrice = 78.0,
                    stockCount = 30,
                    unitLabel = "kg"
                )
            ),
            customers = listOf(
                CustomerEntity(
                    id = 1,
                    name = "Ram Bahadur",
                    phone = "9841234567",
                    pendingBalance = 450.0
                )
            ),
            sales = listOf(
                SaleEntity(
                    id = 1,
                    paymentMode = "CASH",
                    totalAmount = 180.0,
                    estimatedProfit = 24.0,
                    itemCount = 2,
                    summaryText = "Sona Mansuli Rice x2"
                )
            ),
            saleItems = emptyList(),
            udharTransactions = emptyList(),
            cashAdjustments = emptyList(),
            reminderLogs = emptyList()
        )

        val json = BackupManager.toJsonString(snapshot)
        val restoredFromJson = BackupManager.parseBackupContent(json)
        assertEquals("Sita Kirana Pasal", restoredFromJson.shopName)
        assertEquals(1, restoredFromJson.products.size)
        assertEquals(90.0, restoredFromJson.products.first().sellingPrice, 0.01)
        assertEquals(450.0, restoredFromJson.customers.first().pendingBalance, 0.01)

        val csv = BackupManager.toCsvString(snapshot)
        val restoredFromCsv = BackupManager.parseBackupContent(csv)
        assertEquals("Sita Kirana Pasal", restoredFromCsv.shopName)
        assertEquals(1, restoredFromCsv.products.size)
        assertEquals("Ram Bahadur", restoredFromCsv.customers.first().name)
    }

    @Test
    fun `whatsapp reminder builds exact nepali message and formats 977 phone`() {
        val msg = WhatsAppHelper.buildUdharReminderMessage(
            customerName = "Hari",
            shopName = "Shrestha Kirana",
            pendingAmount = 1250.0
        )
        assertTrue(msg.contains("नमस्ते Hari ज्यू"))
        assertTrue(msg.contains("Shrestha Kirana"))
        assertTrue(msg.contains("रु. 1250"))
        assertEquals("9779841000111", WhatsAppHelper.formatNepalPhoneForWhatsApp("9841000111"))
    }

    @Test
    fun `security pin hashing is deterministic and salted`() {
        val h1 = SecurityUtils.hashPin("1234")
        val h2 = SecurityUtils.hashPin("1234")
        val h3 = SecurityUtils.hashPin("5678")
        assertEquals(h1, h2)
        assertNotEquals(h1, h3)
    }
}
